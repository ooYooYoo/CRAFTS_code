#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="/home/fengjiayin/rs/AFL_v5"
PYTHON_BIN="/home/fengjiayin/.conda/envs/rs_new2/bin/python"
RESULT_ROOT="${PROJECT_ROOT}/results/cross_user_transfer"
SEED="2018"
NUM_SHARDS="3"

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
export CRAFTS_SHARE_FROZEN_RETRIEVER=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

cd "${PROJECT_ROOT}"

run_shard() {
  local dataset="$1"
  local shard_index="$2"
  local gpu="$3"
  local test_limit="$4"
  local shard_tag
  shard_tag="$(printf 'shard_%02d_of_%02d' "${shard_index}" "${NUM_SHARDS}")"
  local log_dir="${RESULT_ROOT}/${dataset}/evaluation/wo_skill_shards/${shard_tag}"
  mkdir -p "${log_dir}"
  echo "[launcher] start method=wo_skill_no_sft dataset=${dataset} shard=${shard_tag} gpu=${gpu} test_limit=${test_limit}"
  CUDA_VISIBLE_DEVICES="${gpu}" "${PYTHON_BIN}" "${PROJECT_ROOT}/run_cross_user_transfer.py" \
    --eval-worker \
    --dataset "${dataset}" \
    --method wo_skill \
    --gpus "${gpu}" \
    --output-root "${RESULT_ROOT}" \
    --seed "${SEED}" \
    --test-limit "${test_limit}" \
    --num-shards "${NUM_SHARDS}" \
    --shard-index "${shard_index}" \
    --no-sft \
    > "${log_dir}/nohup.log" 2>&1 &
}

pids=()

run_shard lastfm 0 1 0
pids+=("$!")
run_shard lastfm 1 1 0
pids+=("$!")
run_shard lastfm 2 0 0
pids+=("$!")

run_shard movielens 0 1 0
pids+=("$!")
run_shard movielens 1 1 0
pids+=("$!")
run_shard movielens 2 0 0
pids+=("$!")

run_shard instruments 0 1 200
pids+=("$!")
run_shard instruments 1 1 200
pids+=("$!")
run_shard instruments 2 0 200
pids+=("$!")

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=1
  fi
done

if [[ "${failed}" -ne 0 ]]; then
  echo "[launcher] one or more shards failed; skip merge"
  exit 1
fi

for dataset in lastfm movielens instruments; do
  test_limit="0"
  if [[ "${dataset}" == "instruments" ]]; then
    test_limit="200"
  fi
  echo "[launcher] all shards complete; merging ${dataset}"
  "${PYTHON_BIN}" "${PROJECT_ROOT}/run_cross_user_transfer.py" \
    --merge-shards \
    --dataset "${dataset}" \
    --method wo_skill \
    --output-root "${RESULT_ROOT}" \
    --seed "${SEED}" \
    --test-limit "${test_limit}" \
    --num-shards "${NUM_SHARDS}" \
    --no-sft
done

echo "[launcher] done"
