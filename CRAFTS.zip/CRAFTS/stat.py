import pandas as pd
from pathlib import Path

def stat_inter_file(file_path: str, dataset_name: str = None):
    df = pd.read_csv(file_path, sep="\t")

    user_col = "user_id:token"
    item_col = "item_id:token"

    if user_col not in df.columns or item_col not in df.columns:
        raise ValueError(f"{file_path} 字段名不匹配，当前字段为：{list(df.columns)}")

    return {
        "Dataset": dataset_name or Path(file_path).stem,
        "#Sequence": df[user_col].nunique(),
        "#Item": df[item_col].nunique(),
        "#Interaction": len(df),
    }


if __name__ == "__main__":
    files = {
        "LastFM": "/home/fengjiayin/rs/AFL_v5/data/clean/lastfm/lastfm.inter",
        "MovieLens": "/home/fengjiayin/rs/AFL_v5/data/clean/ml100k/ml100k.inter",
        "Instruments": "/home/fengjiayin/rs/AFL_v5/data/clean/Instruments/Instruments.inter",
    }

    results = []

    for name, path in files.items():
        if Path(path).exists():
            results.append(stat_inter_file(path, name))
        else:
            print(f"[Warning] 文件不存在，跳过：{path}")

    stat_df = pd.DataFrame(results)
    print("\nDataset Statistics")
    print(stat_df.to_string(index=False))