import numpy as np
from collections import defaultdict
from util.FileIO import FileIO
import scipy.sparse as sp
import pickle
from re import split
import random
import os
import json



class DataLoader():
    def __init__(self, args):
        #加载三个数据文件（训练集、验证集、测试集）。
        self.training_data = FileIO.load_data_set(args.data_path + args.dataset + args.training_data)
        self.val_data = FileIO.load_data_set(args.data_path + args.dataset + args.val_data)
        self.test_data = FileIO.load_data_set(args.data_path + args.dataset + args.test_data)

        self.test_data = self.test_data[:1000]   # 只保留1000条（自己调）

        #保存数据集名称
        self.dataName=args.dataset
        #初始化映射字典
        # 原始用户ID → 内部ID
        self.user = {}
        # 原始物品ID → 内部ID
        self.item = {}
        ## 内部ID → 原始用户ID
        self.id2user = {}
        ## 内部ID → 原始物品ID
        self.id2item = {}
        #用户 → {物品: 评分}
        self.training_set_u = defaultdict(dict)
        #物品 → {用户: 评分}
        self.training_set_i = defaultdict(dict)
        #验证集用户交互
        self.val_set = defaultdict(dict)
        #验证集物品集合
        self.val_set_item = set()
        #测试集用户交互
        self.test_set = defaultdict(dict)
        ## 测试集物品集合
        self.test_set_item = set()
        #调用内部方法构建上述映射。
        self.__generate_set()
        #获取用户数和物品数。
        self.user_num = len(self.training_set_u)
        self.item_num = len(self.training_set_i)
        #创建稀疏邻接矩阵（用于图神经网络，如 LightGCN）
        #用户-物品二部图邻接矩阵
        self.ui_adj = self.__create_sparse_bipartite_adjacency()
        #归一化后的邻接矩阵
        self.norm_adj = self.normalize_graph_mat(self.ui_adj)
        #用户-物品交互矩阵
        self.interaction_mat = self.__create_sparse_interaction_matrix()
        #popularity_item[self.item[u]] = len(self.training_set_i[u])
        #打印数据集统计信息：用户数、物品数、交互数量、稀疏度。
        print("user num: {}, item num: {}, training data size: {}".format(self.user_num, self.item_num, len(self.training_data)))
        print("Density of training data: {:.6f}".format(len(self.training_data) / (self.user_num * self.item_num)))
        
        # Optionally load item metadata if arguments specify or if needed for Agent
        #加载元数据，则加载物品的附加信息（如名称、类别）。
        if hasattr(args, 'load_meta') and args.load_meta:
            self.load_item_metadata(args)
            print("Item metadata loaded.")

    #将原始数据转换为内部数据结构
    def __generate_set(self):
        #遍历训练集的每一条记录。
        for entry in self.training_data:
            # Flexible unpacking to handle optional timestamp
            if len(entry) == 4:
                #4个字段：(user, item, rating, timestamp) - 带时间戳
                #rating是用户对物品的偏好程度或交互强度
                user, item, rating, timestamp = entry
            else:
                user, item, rating = entry
                timestamp = 0 # Default if missing

            #如果用户第一次出现，分配一个内部整数ID
            if user not in self.user:
                #self.user[原始ID] = 内部ID
                #self.user["U123"] = 0
                self.user[user] = len(self.user) #id 编号
                #self.id2user[内部ID] = 原始ID（例如 self.id2user[0] = "U123"）
                self.id2user[self.user[user]] = user #id 反向编号
            if item not in self.item:
                self.item[item] = len(self.item) #id 编号
                self.id2item[self.item[item]] = item #id 反向编号
                # userList.append
            #training_set_u[用户原始ID][物品原始ID] = 评分
            #用户和物品的交互数据
            self.training_set_u[user][item] = rating
            self.training_set_i[item][user] = rating
        #处理验证集
        for entry in self.val_data:
            if len(entry) == 4:
                user, item, rating, timestamp = entry
            else:
                 user, item, rating = entry
            
            #验证集中出现的用户如果在训练集中不存在，则跳过该记录。
            #原因：推荐模型只能为训练集中存在的用户做推荐
            if user not in self.user:
                continue
            # [FIX] Register validation items to global item mapping
            #物品注册：验证集中的物品如果不在训练集中，会添加到全局物品映射。
            #原因：验证集中的物品可能是新物品（冷启动场景）
            if item not in self.item:
                self.item[item] = len(self.item)
                self.id2item[self.item[item]] = item
            self.val_set[user][item] = rating
            self.val_set_item.add(item)
        #处理测试集
        for entry in self.test_data:
            if len(entry) == 4:
                user, item, rating, timestamp = entry
            else:
                 user, item, rating = entry 

            #如果在训练集中不存在，则跳过该记录。
            if user not in self.user:
                continue
            # [FIX] Register test items to global item mapping
            if item not in self.item:
                self.item[item] = len(self.item)
                self.id2item[self.item[item]] = item
            self.test_set[user][item] = rating
            self.test_set_item.add(item)
        print(len(self.test_set), "users to process.")
    
    #用户-物品二部图邻接矩阵构建方法
    def __create_sparse_bipartite_adjacency(self, self_connection=False):
        '''
        return a sparse adjacency matrix with the shape (user number + item number, user number + item number)
        '''
        #计算节点总数：例如：2个用户 + 3个物品 = 5个节点
        n_nodes = self.user_num + self.item_num
        #提取用户和物品的内部ID
        #原始training_data = [("U1","I1",1), ("U1","I2",1), ("U2","I2",1)]
        #映射后elf.user = {"U1":0, "U2":1}, self.item = {"I1":0, "I2":1, "I3":2}
        #row_idx = [0, 0, 1] 
        row_idx = [self.user[pair[0]] for pair in self.training_data]
        #col_idx = [0, 1, 1]
        col_idx = [self.item[pair[1]] for pair in self.training_data]
        #转换为NumPy数组
        user_np = np.array(row_idx)
        item_np = np.array(col_idx)
        #创建与 user_np 形状相同的全1数组，作为边的权重。
        #ratings = [1.0, 1.0, 1.0]（这里忽略了原始评分，统一使用1.0。因为对于隐式反馈，只关心"是否有交互"。）
        ratings = np.ones_like(user_np, dtype=np.float32)
        #item_np + self.user_num，这是为了让物品节点的索引从用户节点之后开始。
        tmp_adj = sp.csr_matrix((ratings, (user_np, item_np + self.user_num)), shape=(n_nodes, n_nodes),dtype=np.float32)
        #添加转置得到对称矩阵
        adj_mat = tmp_adj + tmp_adj.T
        #可选的自连接
        if self_connection:
            adj_mat += sp.eye(n_nodes)
        return adj_mat

    #对图邻接矩阵进行归一化，使得每个节点的信息被其度数缩放（所有节点的嵌入值保持在相似的数值范围内，训练更稳定。）
    def normalize_graph_mat(self, adj_mat):
        #获取矩阵的形状 (行数, 列数)。
        shape = adj_mat.get_shape()
        #adj_mat.sum(1)：对每一行求和，得到每个节点的度
        rowsum = np.array(adj_mat.sum(1))
        #判断矩阵是否为方阵（行数 = 列数）。
        if shape[0] == shape[1]:
            #计算 rowsum^(-0.5)，即 1 / sqrt(度)，然后展平
            #rowsum = [[2], [1], [0], [2], [1]]
            #d_inv = [0.7071, 1.0, inf, 0.7071, 1.0]
            d_inv = np.power(rowsum, -0.5).flatten()
            #把inf替换成0
            d_inv[np.isinf(d_inv)] = 0.
            d_mat_inv = sp.diags(d_inv)
            norm_adj_tmp = d_mat_inv.dot(adj_mat)
            norm_adj_mat = norm_adj_tmp.dot(d_mat_inv)
        else:
            d_inv = np.power(rowsum, -1).flatten()
            d_inv[np.isinf(d_inv)] = 0.
            d_mat_inv = sp.diags(d_inv)
            norm_adj_mat = d_mat_inv.dot(adj_mat)
        return norm_adj_mat

    def load_item_metadata(self, args):
        """
        Load meta data (id2name map) for Agent Recommend.
        """
        self.item_meta_dict = {}
        import os
        import json

        #构建 JSON 文件路径
        json_path = args.data_path + args.dataset + "/id2meta.json"
        
        if os.path.exists(json_path):
            print(f"Loading item metadata from {json_path}")
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    meta_json = json.load(f)
                    #遍历并存储元数据，k：物品的原始 ID，v：该物品的元数据字典
                    for k, v in meta_json.items():
                        self.item_meta_dict[str(k)] = v
                        try:
                            self.item_meta_dict[int(k)] = v
                        except:
                            pass
            except Exception as e:
                print(f"Error loading JSON metadata: {e}")
        else:
            print(f"Warning: {json_path} not found. Agent will use Item IDs.")

    #通过物品的内部 ID 获取该物品的元数据
    def get_item_name(self, i):
        """
        Get item name by internal item ID.
        """
        if not hasattr(self, 'item_meta_dict'):
             return f"Item_{i}"
             
        if i in self.id2item:
            raw_id = self.id2item[i]
            if raw_id in self.item_meta_dict:
                return self.item_meta_dict[raw_id]
            # Fallback if raw_id is int but stored as str or vice versa
            if str(raw_id) in self.item_meta_dict:
                return self.item_meta_dict[str(raw_id)]
            return str(raw_id)
        return f"Unknown_Item_{i}"

    #接收一个用户内部 ID，返回该用户历史交互过的所有物品名称列表：
    def get_user_history_names(self, u):
        """
        Get the list of item names interacted by user u (internal user ID)
        """
        #获取用户的原始id
        raw_u = self.id2user.get(u)
        if raw_u is None or raw_u not in self.training_set_u:
            return []
        ##training_set_u存储用户 → {物品: 评分}数据
        item_ids = list(self.training_set_u[raw_u].keys())
        names = []
        for raw_i in item_ids:
            #判断：这个原始物品ID 是否在物品映射表中
            if raw_i in self.item:
                #通过物品内部ID，查询并添加【物品真实名称】
                internal_i = self.item[raw_i]
                names.append(self.get_item_name(internal_i))
            else:
                names.append(str(raw_i))
        return names

    #图神经网络（GNN）/ 推荐系统里构建拉普拉斯矩阵
    def convert_to_laplacian_mat(self, adj_mat):
        #将用户-物品邻接矩阵 转换为 图拉普拉斯矩阵
        #获取输入矩阵的形状：用户数 × 物品数（推荐系统标准邻接矩阵）
        adj_shape = adj_mat.get_shape()
        #计算总节点数：用户数+物品数
        n_nodes = adj_shape[0]+adj_shape[1]
        #提取稀疏矩阵中非0元素的坐标（即有交互的 用户-物品 对）
        (user_np_keep, item_np_keep) = adj_mat.nonzero()
        #提取非0元素的值（评分/交互权重，如点击=1、评分=5）
        ratings_keep = adj_mat.data
        #构造【全图邻接矩阵】（大小：总节点数 × 总节点数）
        tmp_adj = sp.csr_matrix((ratings_keep, (user_np_keep, item_np_keep + adj_shape[0])),shape=(n_nodes, n_nodes),dtype=np.float32)
        tmp_adj = tmp_adj + tmp_adj.T
        return self.normalize_graph_mat(tmp_adj)

    #构建一个【用户 × 物品】大小的稀疏交互矩阵
    def __create_sparse_interaction_matrix(self):
        """
        return a sparse adjacency matrix with the shape (user number, item number)
        """
        #初始化三个空列表，用来存：行号、列号、值
        row, col, entries = [], [], []
        for pair in self.training_data:
            row += [self.user[pair[0]]]
            col += [self.item[pair[1]]]
            entries += [1.0]
        interaction_mat = sp.csr_matrix((entries, (row, col)), shape=(self.user_num,self.item_num),dtype=np.float32)
        return interaction_mat
    #输入：用户原始 ID（真实 ID） → 输出：用户内部 ID
    def get_user_id(self, u):
        if u in self.user:
            return self.user[u]
    #输入：物品原始 ID（真实 ID） → 输出：物品内部 ID
    def get_item_id(self, i):
        if i in self.item:
            return self.item[i]
    #训练集大小
    def training_size(self):
        return len(self.user), len(self.item), len(self.training_data)
    #查询【某个用户是否和某个物品有过交互】
    def contain(self, u, i):
        'whether user u rated item i'
        if u in self.user and i in self.training_set_u[u]:
            return True
        else:
            return False

    def contain_user(self, u):
        'whether user is in training set'
        if u in self.user:
            return True
        else:
            return False

    def contain_item(self, i):
        """whether item is in training set"""
        if i in self.item:
            return True
        else:
            return False
    #返回一个用户交互过的【所有物品 ID 列表】 + 【对应的评分 / 权重列表】
    #(["itemA", "itemB", "itemC"], [5, 4, 1])
    def user_rated(self, u):
        return list(self.training_set_u[u].keys()), list(self.training_set_u[u].values())
    #返回物品交互过的用户
    def item_rated(self, i):
        return list(self.training_set_i[i].keys()), list(self.training_set_i[i].values())

    #从训练数据中，构建一个【用户数 × 物品数】的稀疏交互矩阵，专门给攻击模型使用。
    def matrix(self):
        """
        Create and return a sparse interaction matrix with shape (user_num, item_num).
        Used by attack models.
        """
        import scipy.sparse as sp
        row, col, entries = [], [], []
        
        # Build matrix from training_data
        for entry in self.training_data:
            user_internal = int(entry[0])  # Internal user ID (ensure int)
            item_internal = int(entry[1])  # Internal item ID (ensure int)
            rating = float(entry[2]) if len(entry) > 2 else 1.0
            
            row.append(user_internal)
            col.append(item_internal)
            entries.append(rating)
        
        # Determine actual matrix dimensions from max IDs
        #自动计算实际需要的矩阵大小（鲁棒性设计）
        #如果有数据，就用最大ID+1；没有就用预设的user_num
        max_user = max(row) + 1 if row else self.user_num
        max_item = max(col) + 1 if col else self.item_num
        
        # Use the larger of declared size or actual max ID
        num_users = max(self.user_num, max_user)
        num_items = max(self.item_num, max_item)
        
        # Create sparse matrix
        interaction_mat = sp.csr_matrix(
            (entries, (row, col)), 
            shape=(num_users, num_items),
            dtype='float32'
        )
        return interaction_mat






# util/DataLoader.py
import os
from collections import defaultdict
import scipy.sparse as sp

#让数字按数字大小从小到大排序，字符串按字母顺序排序，并且所有数字永远排在字符串前面！
def _sort_key_token(x):
    s = str(x)
    return (0, int(s)) if s.isdigit() else (1, s)

#定义一个类，专门读取原始交互数据
class DataLoader_recbole_Raw:
    """只负责读取 {dataset}.inter，提供给 BenchmarkSplitter 使用。"""

    def __init__(self, args):
        self.args = args
        #拼接数据集文件夹路径,如./data/ml-100k
        self.dataset_dir = os.path.join(args.data_path, args.dataset)
        #拼接 .inter 文件完整路径，例：./data/ml-100k/ml-100k.inter（这是真正要读取的交互文件）
        self.inter_path = os.path.join(self.dataset_dir, f"{args.dataset}.inter")

        #字段分隔符，默认是制表符 \t
        self.field_sep = getattr(args, "field_separator", "\t")

        #定义 4 个关键字段名（列名）
        self.USER_ID_FIELD = getattr(args, "USER_ID_FIELD", "user_id")
        self.ITEM_ID_FIELD = getattr(args, "ITEM_ID_FIELD", "item_id")
        self.RATING_FIELD  = getattr(args, "RATING_FIELD", "rating")
        self.TIME_FIELD    = getattr(args, "TIME_FIELD", "timestamp")

        #调用加载函数，把 .inter 文件读到内存
        #结果保存到 self.inter_data
        self.inter_data = self._load_inter_file(self.inter_path)

    def _load_inter_file(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Raw inter file not found: {path}")

        data = []
        with open(path, "r", encoding="utf-8") as f:
            #读取第一行（表头），按分隔符切分成列表
            header = f.readline().rstrip("\n").split(self.field_sep)
            #处理表头：例如 user_id:token → 取 user_id
            fields = [h.split(":")[0] for h in header]

            #找到 用户 ID、物品 ID 在第几列，记录列索引
            idx_u = fields.index(self.USER_ID_FIELD)
            idx_i = fields.index(self.ITEM_ID_FIELD)
            idx_r = fields.index(self.RATING_FIELD) if self.RATING_FIELD in fields else None
            idx_t = fields.index(self.TIME_FIELD) if self.TIME_FIELD in fields else None

            # 遍历每一行数据
            for line in f:
                #遍历每一行数据
                line = line.rstrip("\n")
                if not line:
                    continue
                #按分隔符把一行切成多列
                cols = line.split(self.field_sep)

                #取用户 ID、物品 ID
                u = cols[idx_u]
                i = cols[idx_i]
                #取评分：有就用，没有默认 1.0
                r = float(cols[idx_r]) if idx_r is not None and cols[idx_r] != "" else 1.0
                #取时间戳：有就用，没有默认 0.0
                t = float(cols[idx_t]) if idx_t is not None and cols[idx_t] != "" else 0.0
                data.append((u, i, r, t))
        return data


class DataLoader_recbole:
    """
    你的框架/Agent 用的轻量级 DataLoader。
    保留对外接口：
      - matrix()
      - get_user_history_by_internal_id(u_int)
      - load_item_metadata(args)
      - get_item_meta(i_int, fields=None)

    注意：此 loader 读取 benchmark 文件（已含 item_id_list）。
    """
    #加载 RecBole 格式的训练 / 验证 / 测试文件 → 构建全局用户 / 物品 ID 映射 → 生成模型需要的所有数据结构
    #输入：.train.inter / .valid.inter / .test.inter
    #输出：内部 ID、历史序列、交互矩阵、元数据
    def __init__(self, args, agent_args=None):
        #保存配置
        self.args = args
        #数据集名称
        self.dataName = args.dataset

        #字段分隔符：默认制表符 \t
        self.field_sep = getattr(args, "field_separator", "\t")
        #序列分隔符：历史序列用空格分隔
        self.seq_sep = getattr(args, "seq_separator", " ")

        #定义 4 个核心字段名
        self.USER_ID_FIELD = getattr(args, "USER_ID_FIELD", "user_id")
        self.ITEM_ID_FIELD = getattr(args, "ITEM_ID_FIELD", "item_id")
        self.RATING_FIELD = getattr(args, "RATING_FIELD", "rating")
        self.TIME_FIELD = getattr(args, "TIME_FIELD", "timestamp")

        #历史序列列名：item_id_list（存储用户历史交互物品序列）
        self.SEQ_FIELD = f"{self.ITEM_ID_FIELD}_list"  # item_id_list

        #拼接所有文件路径
        self.dataset_dir = os.path.join(args.data_path, args.dataset)
        self.train_path = os.path.join(self.dataset_dir, f"{args.dataset}.train.inter")
        self.valid_path = os.path.join(self.dataset_dir, f"{args.dataset}.valid.inter")
        self.test_path  = os.path.join(self.dataset_dir, f"{args.dataset}.test.inter")
        #物品元数据
        self.item_path  = os.path.join(self.dataset_dir, f"{args.dataset}.item")

        #加载训练 / 验证 / 测试原始数据
        print(f"[DataLoader] Loading benchmark files from {self.dataset_dir}...")
        train_raw = self._load_benchmark_file(self.train_path)
        valid_raw = self._load_benchmark_file(self.valid_path)
        test_raw  = self._load_benchmark_file(self.test_path)

        # 全局 ID 映射必须覆盖：目标 item + 历史 item（避免历史里有 token 但没进词表）
        #全局 ID 映射
        all_users, all_items = set(), set()
        for data_list in [train_raw, valid_raw, test_raw]:
            for (u, i, r, t, hist) in data_list:
                all_users.add(u)       # 收集所有用户
                all_items.add(i)       # 收集所有目标物品
                for hi in hist:
                    all_items.add(hi)  # 收集历史里的所有物品，避免：历史里有物品，但没进 ID 映射表
        #原始 ID → 内部数字 ID
        self.user = {u: idx for idx, u in enumerate(sorted(all_users, key=_sort_key_token))}
        self.item = {i: idx for idx, i in enumerate(sorted(all_items, key=_sort_key_token))}
        #内部 ID → 原始 ID
        self.id2user = {idx: u for u, idx in self.user.items()}
        self.id2item = {idx: i for i, idx in self.item.items()}
        #总用户数、总物品数
        self.user_num = len(self.user)
        self.item_num = len(self.item)

        # 转 internal
        #把所有原始数据 转换成内部 ID 格式
        self.training_data = self._to_internal(train_raw)  # (u_int, i_int, r, t, hist_int)
        self.val_data      = self._to_internal(valid_raw)
        self.test_data     = self._to_internal(test_raw)
        
        print(f"[DataLoader] Done. Users: {self.user_num}, Items: {self.item_num}")
        print(f"[DataLoader] Train: {len(self.training_data)}, Val: {len(self.val_data)}, Test: {len(self.test_data)}")

        # 训练交互字典（internal）
        #快速查询：用户是否交互过物品、用户历史列表
        self.training_set_u = defaultdict(dict)  # u_int -> {i_int: rating}
        self.training_set_i = defaultdict(dict)  # i_int -> {u_int: rating}
        for (u, i, r, t, hist) in self.training_data:
            self.training_set_u[u][i] = r # 用户交互过哪些物品
            self.training_set_i[i][u] = r # 物品被哪些用户交互

        # 这里按你当前实现：返回 test 语义的“完整历史”（来自 test 文件每个用户那一行的 hist）
        #测试集用户的完整历史序列,用于测试推荐效果
        self._test_hist_seq = {u: hist for (u, i, r, t, hist) in self.test_data}

        # 元数据
        self.item_meta = {}
        if getattr(args, "load_meta", False):
            self.load_item_metadata(args)

    def _load_benchmark_file(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Benchmark file not found: {path}")

        rows = []
        with open(path, "r", encoding="utf-8") as f:
            header = f.readline().rstrip("\n").split(self.field_sep)
            fields = [h.split(":")[0] for h in header]
            types  = [h.split(":")[1] if ":" in h else "token" for h in header]

            idx_u = fields.index(self.USER_ID_FIELD)
            idx_i = fields.index(self.ITEM_ID_FIELD)
            idx_r = fields.index(self.RATING_FIELD) if self.RATING_FIELD in fields else None
            idx_t = fields.index(self.TIME_FIELD) if self.TIME_FIELD in fields else None
            #idx_s：历史序列 item_id_list 在第几列
            idx_s = fields.index(self.SEQ_FIELD) if self.SEQ_FIELD in fields else None

            for line in f:
                line = line.rstrip("\n")
                if not line:
                    continue
                cols = line.split(self.field_sep)

                u = cols[idx_u]
                i = cols[idx_i]
                r = float(cols[idx_r]) if idx_r is not None and cols[idx_r] != "" else 1.0
                t = float(cols[idx_t]) if idx_t is not None and cols[idx_t] != "" else 0.0

                hist = []
                if idx_s is not None and idx_s < len(cols):
                    s = cols[idx_s].strip()
                    hist = s.split(self.seq_sep) if s else []

                rows.append((u, i, r, t, hist))
        return rows
    
    # 把「原始 ID」的交互数据 → 转换成「内部数字 ID」的模型可用数据
    def _to_internal(self, raw_list):
        out = []
        for (u, i, r, t, hist) in raw_list:
            if u not in self.user or i not in self.item:
                continue
            u_int = self.user[u]
            i_int = self.item[i]
            hist_int = [self.item[hi] for hi in hist if hi in self.item]
            out.append((u_int, i_int, float(r), float(t), hist_int))
        return out

    # ===== 对外接口（保留） =====
    #把训练好的内部 ID 交互数据，直接转换成【用户 × 物品】的稀疏交互矩阵
    def matrix(self):
        row, col, data = [], [], []
        for (u, i, r, t, hist) in self.training_data:
            row.append(u)
            col.append(i)
            data.append(r)
        return sp.csr_matrix((data, (row, col)), shape=(self.user_num, self.item_num))

    #输出：该用户在【测试集】里的【完整历史交互物品列表】
    def get_user_history_by_internal_id(self, u_int):
        return self._test_hist_seq.get(u_int, [])

    def load_item_metadata(self, args):
            self.item_meta = {}
        #     self.item_meta = {
        #     "item1": {
        #         "item_id": "item1",
        #         "title": "The Shawshank Redemption",
        #         "genre": "Drama",
        #         "rating": 9.3
        #     },
        #     "item2": { ... },
        #     ...
        # }
            # 1. 检查文件是否存在
            if not os.path.exists(self.item_path):
                print(f"[Warning] Meta file not found: {self.item_path}")
                return

            print(f"[DataLoader] Loading item metadata from {self.item_path}...")

            with open(self.item_path, "r", encoding="utf-8") as f:
                # 2. 读取并解析 Header
                try:
                    header_line = f.readline().rstrip("\n")
                    #按制表符 \t 分割成列名
                    header = header_line.split(self.field_sep)
                except Exception:
                    print("[Error] Failed to read header.")
                    return

                # 解析字段名和类型,如 rating:float → 类型是浮点数
                fields = []
                types = []
                for h in header:
                    if ":" in h:
                        k, v = h.split(":")[:2]
                        fields.append(k)
                        types.append(v)
                    else:
                        fields.append(h)
                        types.append("token")
                
                # 找到 item_id 的位置,找到 物品 ID 所在列
                try:
                    idx_iid = fields.index(self.ITEM_ID_FIELD)
                except ValueError:
                    print(f"[Warning] ID field '{self.ITEM_ID_FIELD}' not found. Skipping metadata.")
                    return

                # 3. 逐行读取（带容错机制）
                success_count = 0
                error_count = 0
                
                for line in f:
                    line = line.rstrip("\n")
                    if not line:
                        continue
                    
                    cols = line.split(self.field_sep)
                    row = {}

                    # 安全遍历每一列
                    for idx, (name, ftype) in enumerate(zip(fields, types)):
                        if idx >= len(cols):
                            break
                        
                        val = cols[idx]
                        
                        # === 核心修复：遇到烂数据自动填 0.0 ===
                        if ftype == "float" and val:
                            try:
                                row[name] = float(val)
                            except ValueError:
                                # 比如读到了 'Tools & Home Improvement'，转不了一点
                                # 我们就填 0.0，假装它没有排名
                                row[name] = 0.0 
                                error_count += 1
                        else:
                            row[name] = val
                        # ===================================

                    # 只有当 ID 存在时才保存
                    if idx_iid < len(cols):
                        iid = cols[idx_iid]
                        self.item_meta[str(iid)] = row
                        success_count += 1
            
            print(f"[DataLoader] Metadata loaded. Success: {success_count} items. "
                f"Corrupted Fields (Auto-filled 0.0): {error_count}")
            

    def get_item_meta(self, i_int, fields=None):
        raw_i = str(self.id2item.get(i_int))
        meta = self.item_meta.get(raw_i, {})
        if fields:
            return {k: meta.get(k) for k in fields}
        return meta


#识别恶意攻击用户
class DataLoader_detect():
    def __init__(self, args):
        self.training_data = self.load_data_label(args.detectDatasetPath + '/train.txt')
        self.val_data = self.load_data_label(args.detectDatasetPath + '/val.txt')
        self.test_data = self.load_data_label(args.detectDatasetPath + '/test.txt')
        self.interact_data = self.load_data_interact(args.detectDatasetPath + '/ratings.txt')

        self.user = {}
        self.item = {}
        self.id2user = {}
        self.id2item = {}
        self.set_u = defaultdict(dict)
        self.set_i = defaultdict(dict)
        self.__generate_set()
        self.user_num = len(self.set_u)
        self.item_num = len(self.set_i)
        self.interaction_mat = self.__create_sparse_interaction_matrix()

    def __generate_set(self):
        for entry in self.interact_data:
            user, item, rating = entry
            if user not in self.user:
                self.user[user] = len(self.user)
                self.id2user[self.user[user]] = user
            if item not in self.item:
                self.item[item] = len(self.item)
                self.id2item[self.item[item]] = item
                # userList.append
            self.set_u[user][item] = rating
            self.set_i[item][user] = rating

    def load_data_interact(self, file):
        data = []
        with open(file) as f:
            for line in f:
                items = split(' ', line.strip())
                user_id = items[0]
                item_id = items[1]
                weight = items[2]
                data.append([user_id, item_id, float(weight)])
        return data

    def load_data_label(self, file):
        data = {}
        with open(file) as f:
            for line in f:
                items = split(' ', line.strip())
                user_id = items[0]
                label = int(items[1])
                data[user_id] = label
        return data

    def __create_sparse_interaction_matrix(self):
        """
        return a sparse adjacency matrix with the shape (user number, item number)
        """
        row, col, entries = [], [], []
        for pair in self.interact_data:
            row += [self.user[pair[0]]]
            col += [self.item[pair[1]]]
            entries += [pair[2]]
        interaction_mat = sp.csr_matrix((entries, (row, col)), shape=(self.user_num, self.item_num),dtype=np.float32)
        return interaction_mat

    def shuffle_data(self, data):
        shuffled_keys = list(data.keys())
        random.shuffle(shuffled_keys)
        shuffled_data = {key: data[key] for key in shuffled_keys}
        return shuffled_data
    
    # def expanded_data(self, data):
    #     label_1_samples = {key: value for key, value in data.items() if value == 1}
    #     label_0_samples = {key: value for key, value in data.items() if value == 0}
    #     num = len(label_0_samples) - len(label_1_samples)
    #     existing_label_1_keys = list(label_1_samples.keys())
    #     for i in range(num):
    #         sampled_key = random.choice(existing_label_1_keys)  
    #         new_key = f"{sampled_key}_dup_{i}"
    #         label_1_samples[new_key] = 1

    #     combined_data = {**label_0_samples, **label_1_samples}