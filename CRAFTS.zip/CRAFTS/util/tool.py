import os
import random
import numpy as np
import torch
import shutil

def isClass(obj, classList):
    """
    If obj is in classList, return True
    else return False
    """
    for i in classList:
        if isinstance(obj, i):
            return True
    return False

import os
import shutil
import collections

import os
import shutil
import collections

def save_poison_data_recbole(poison_ratings, output_dir, dataset_name, recommend_arg,
                             data_loader, origin_dir=None):
    """
    保存中毒数据（poison_ratings 现在仅包含 fake 用户交互）：
    1) 复制原始 .train.inter 到 output_dir
    2) 追加 fake 用户对应的 train 行（含 item_id_list）
    3) 复制原始 .valid.inter / .test.inter / .item / .user
    4) 额外保存 fake user raw id 到 txt
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print(f"Saving RecBole format poisoned data to {output_dir}")

    # 固定：RecBole benchmark 文件一般用 Tab；序列用空格分隔。[web:51]
    sep = "\t"
    seq_sep = " "

    u_field = getattr(recommend_arg, "USER_ID_FIELD", "user_id")
    i_field = getattr(recommend_arg, "ITEM_ID_FIELD", "item_id")
    r_field = getattr(recommend_arg, "RATING_FIELD", "rating")
    t_field = getattr(recommend_arg, "TIME_FIELD", "timestamp")

    train_file = os.path.join(output_dir, f"{dataset_name}.train.inter")

    # -----------------------------------------------------------
    # 0) 先复制原始文件（包含 train）
    # -----------------------------------------------------------
    if origin_dir:
        files_to_copy = [
            f"{dataset_name}.train.inter",
            f"{dataset_name}.valid.inter",
            f"{dataset_name}.test.inter",
            f"{dataset_name}.item",
            f"{dataset_name}.user",
        ]

        print(f"[Poison Save] Copying benchmark files from {origin_dir}...")
        for fname in files_to_copy:
            src = os.path.join(origin_dir, fname)
            dst = os.path.join(output_dir, fname)
            if os.path.exists(src):
                if os.path.exists(dst):
                    os.remove(dst)
                shutil.copy(src, dst)
                print(f"  -> Copied {fname}")
            else:
                if fname.endswith(".inter"):
                    print(f"  -> [WARNING] Critical file missing in origin: {src}")
    else:
        # 如果没有 origin_dir，就只能退化为“只写 fake train”
        header_cols = [
            f"{u_field}:token",
            f"{i_field}:token",
            f"{r_field}:float",
            f"{t_field}:float",
            "item_id_list:token_seq"
        ]
        with open(train_file, "w", encoding="utf-8") as f:
            f.write(sep.join(header_cols) + "\n")

    # -----------------------------------------------------------
    # 1) 保存 fake user id 到 txt
    # -----------------------------------------------------------
    fake_users = []
    seen = set()
    for row in poison_ratings:
        u = str(row[0])
        if u not in seen:
            seen.add(u)
            fake_users.append(u)

    fake_uid_path = os.path.join(output_dir, "fake_user_ids.txt")
    with open(fake_uid_path, "w", encoding="utf-8") as f:
        for u in fake_users:
            f.write(u + "\n")
    print(f"[Poison Save] Saved fake user ids -> {fake_uid_path} (count={len(fake_users)})")

    # -----------------------------------------------------------
    # 2) 追加 fake 用户训练样本到 .train.inter
    # -----------------------------------------------------------
    # 分组与排序（仅对 fake 用户）
    user_interactions = collections.defaultdict(list)
    for row in poison_ratings:
        # poison_ratings 格式: [u_raw, i_raw, rating, timestamp]
        u, i, r, t = row[0], row[1], row[2], row[3]
        user_interactions[str(u)].append((str(u), str(i), float(r), float(t)))

    for u in user_interactions:
        user_interactions[u].sort(key=lambda x: x[3])

    print(f"[Poison Save] Appending fake interactions into train file: {train_file}")
    with open(train_file, "a", encoding="utf-8") as f:
        for u, interactions in user_interactions.items():
            seq_items = [x[1] for x in interactions]
            n_inter = len(interactions)

            # sliding window：k 从 1 开始，保证 history 非空
            for k in range(1, n_inter):
                target = interactions[k]
                history = seq_items[:k]
                hist_str = seq_sep.join(str(x) for x in history)

                line = [
                    target[0],            # user_id
                    target[1],            # item_id
                    str(float(target[2])),# rating
                    str(float(target[3])),# timestamp
                    hist_str              # item_id_list
                ]
                f.write(sep.join(line) + "\n")


def getPopularItemId(interact, n):
    """
    Get the id of the top n popular items based on the number of ratings
    :return: id list
    """
    return np.argsort(interact[:, :].sum(0))[-n:]

# def dataSave(ratings, fileName, id2user, id2item):
#     """
#     sava ratings data
#     :param ratings: np.array ratings matrix
#     :param fileName: str fileName
#     :param id2user: dict
#     :param id2item: dcit
#     """
#     ratingList = []
#     #print("Ratings:", ratings)
#     ind = ratings.nonzero()
#     for i,j in zip(ind[0].tolist(),ind[1].tolist()):
#             ratingList.append((i,j,ratings[i,j]))
#     # for i in range(ratings.shape[0]):
#     #     for j in range(ratings.shape[1]):
#     #         if ratings[i,j] == 0: continue
#     #         ratingList.append((i, j, ratings[i,j]))
#     text = []
#     for i in ratingList:
#         if i[0] in id2user.keys():
#             userId = id2user[i[0]]
#         else:
#             userId = "fakeUser" + str(i[0])
#         itemId = id2item[i[1]]
#         new_line = '{} {} {}'.format(userId, itemId, i[2]) + '\n'
#         text.append(new_line)
#     with open(fileName, 'w') as f:
#         f.writelines(text)
import numpy as np
import scipy.sparse as sp

def dataSave(ratings, file_path, user_map=None, item_map=None):
    """
    保存数据到 txt 文件。
    支持输入格式：
    1. Python List (适用于 Agent/Sequence 模型，保留时间戳和顺序)
       格式: [[uid, iid, rating, timestamp], ...] 或 [[uid, iid, rating], ...]
    2. SciPy Sparse Matrix / Numpy Array (适用于传统 MF 模型，无时间戳)
    """
    print(f"Saving data to {file_path}...")
    
    with open(file_path, 'w') as f:
        # ---------------------------------------------------------
        # 情况 1: 输入是 Python List (新逻辑)
        # ---------------------------------------------------------
        if isinstance(ratings, list):
            for entry in ratings:
                # entry 可能是 [uid, iid, rating, ts] 或其他长度
                if isinstance(entry, (list, tuple)):
                    # 转换为 Raw ID (如果传入了 map 且 entry 存的是 Internal ID)
                    # 注意：通常 poisonDataAttack 返回的已经是 Internal ID，
                    # 但 dataSave 的参数 user_map/item_map 通常是 id2user/id2item
                    # 如果需要转回 Raw ID 保存：
                    uid, iid = entry[0], entry[1]
                    rest = entry[2:]
                    
                    if user_map and uid in user_map:
                        uid = user_map[uid]
                    if item_map and iid in item_map:
                        iid = item_map[iid]
                        
                    # 拼接行字符串
                    line_parts = [str(uid), str(iid)] + [str(x) for x in rest]
                    f.write(' '.join(line_parts) + '\n')
                else:
                    # 已经是字符串
                    f.write(str(entry).strip() + '\n')
                    
        # ---------------------------------------------------------
        # 情况 2: 输入是 Matrix (旧逻辑)
        # ---------------------------------------------------------
        elif isinstance(ratings, (np.ndarray, sp.spmatrix)):
            # 获取非零元素的索引
            if sp.issparse(ratings):
                rows, cols = ratings.nonzero()
                # 获取数据值 (ratings)
                # 注意：csr_matrix[row, col] 索引可能较慢，直接用 data 属性更高效
                if isinstance(ratings, sp.csr_matrix):
                    data = ratings.data
                else:
                    # Fallback
                    data = [ratings[r, c] for r, c in zip(rows, cols)]
            else:
                rows, cols = ratings.nonzero()
                data = ratings[rows, cols]

            for r, c, d in zip(rows, cols, data):
                uid, iid = r, c
                # 转换 Raw ID
                if user_map and uid in user_map:
                    uid = user_map[uid]
                if item_map and iid in item_map:
                    iid = item_map[iid]
                
                # 写入格式: uid iid rating
                f.write(f"{uid} {iid} {d}\n")
        
        else:
            print(f"Error: Unsupported data type {type(ratings)} in dataSave")
def dataSave_timestamp(data_list, fileName, id2user, id2item):
    """
    配套的保存函数，用于处理包含时间戳的列表数据
    :param data_list: list of [uid_internal, iid_internal, rating, timestamp]
    """
    text = []
    for row in data_list:
        u_internal, i_internal, rating, timestamp = row
        
        # 1. 还原 User ID
        if u_internal in id2user:
            userId = id2user[u_internal]
        else:
            # 这是一个虚假用户 (ID超出了原始id2user范围)
            userId = "fakeUser" + str(u_internal)
            
        # 2. 还原 Item ID
        itemId = id2item[i_internal]
        
        # 3. 格式化写入：User Item Rating Timestamp
        new_line = '{} {} {} {}'.format(userId, itemId, int(rating), timestamp) + '\n'
        text.append(new_line)

    with open(fileName, 'w') as f:
        f.writelines(text)

def detectDataSave(ratings, fileName, id2user, id2item):
    """
    保存用于检测的数据 (Detect Data)。
    支持输入: 
    1. Python List (Agent模式，带时间戳)
    2. Sparse Matrix / Numpy Array (传统模式)
    """
    import os
    import random
    import scipy.sparse as sp

    if not os.path.exists(fileName):
        os.makedirs(fileName)

    # 1. 统一数据格式为 list of (uid, iid, rating)
    ratingList = []

    # --- 情况 A: 输入是 List (Agent/Sequence 模型) ---
    if isinstance(ratings, list):
        for entry in ratings:
            # entry: [uid, iid, rating, timestamp] 或 [uid, iid, rating]
            # 我们只需要前三项
            uid, iid, val = entry[0], entry[1], entry[2]
            ratingList.append((uid, iid, val))

    # --- 情况 B: 输入是 Matrix (传统 MF 模型) ---
    elif hasattr(ratings, 'nonzero'):
        if sp.issparse(ratings):
            rows, cols = ratings.nonzero()
            # 获取数据值，优先使用 .data 属性以提高效率
            if hasattr(ratings, 'data'):
                data = ratings.data
            else:
                data = [ratings[r, c] for r, c in zip(rows, cols)]
        else:
            # Numpy dense array
            rows, cols = ratings.nonzero()
            data = ratings[rows, cols]
        
        for r, c, v in zip(rows, cols, data):
            ratingList.append((r, c, v))
    else:
        raise ValueError(f"Unsupported ratings type: {type(ratings)}")

    # 2. 处理数据并生成 Label (逻辑与原代码保持一致)
    ratingText = []
    normal = []
    fake = []

    for item in ratingList:
        uid, iid, val = item[0], item[1], item[2]

        # 判断用户类型并转换 ID
        if uid in id2user:
            # 真实用户：在 id2user 映射中
            userId = str(id2user[uid])
            is_fake = False
        else:
            # 虚假用户：不在映射中 (攻击注入的用户)
            # 原逻辑是加前缀 "fakeUser" 再去掉，这里直接用 uid 即可
            userId = str(uid) 
            is_fake = True

        # 转换 Item ID
        if iid in id2item:
            itemId = str(id2item[iid])
        else:
            itemId = str(iid)

        # 生成 ratings.txt 的一行
        new_line = '{} {} {}\n'.format(userId, itemId, val)
        ratingText.append(new_line)

        # 分类到 normal 或 fake 列表 (用于生成 labels)
        if is_fake:
            fake.append(f"{userId} 1\n")
        else:
            normal.append(f"{userId} 0\n")

    # 去重
    fake = list(set(fake))
    normal = list(set(normal))

    # 保存 ratings.txt
    with open(fileName + "ratings.txt", 'w') as f:
        f.writelines(ratingText)

    # 3. 划分数据集 (Train/Val/Test)
    # 打乱顺序
    random.shuffle(normal)
    random.shuffle(fake)

    # 计算划分大小
    train_size_normal = int(len(normal) * 0.6)
    test_size_normal = int(len(normal) * 0.2)
    # val_size_normal 隐式计算

    train_size_fake = int(len(fake) * 0.6)
    test_size_fake = int(len(fake) * 0.2)
    # val_size_fake 隐式计算

    # 执行划分
    train = normal[:train_size_normal] + fake[:train_size_fake]
    test = normal[train_size_normal:train_size_normal + test_size_normal] + fake[train_size_fake:train_size_fake + test_size_fake]
    val = normal[train_size_normal + test_size_normal:] + fake[train_size_fake + test_size_fake:]

    # 保存结果
    with open(fileName + 'train.txt', 'w') as f:
        f.writelines(train)

    with open(fileName + 'test.txt', 'w') as f:
        f.writelines(test)

    with open(fileName + 'val.txt', 'w') as f:
        f.writelines(val)
# def detectDataSave(ratings, fileName, id2user, id2item):
#     if not os.path.exists(fileName):
#         os.makedirs(fileName)
#     ratingList = []
#     ind = ratings.nonzero()
#     for i,j in zip(ind[0].tolist(),ind[1].tolist()):
#             ratingList.append((i,j,ratings[i,j]))
#     # for i in range(ratings.shape[0]):
#     #     for j in range(ratings.shape[1]):
#     #         if ratings[i,j] == 0: continue
#     #         ratingList.append((i, j, ratings[i,j]))
#     ratingText = []
#     normal = []
#     fake = []
#     for i in ratingList:
#         if i[0] in id2user.keys():
#             userId = id2user[i[0]]
#         else:
#             userId = "fakeUser" + str(i[0])
#         itemId = id2item[i[1]]
#         if i[0] in id2user.keys():
#             new_line = '{} {} {}'.format(userId, itemId, i[2]) + '\n'
#         else:
            
#             new_line = '{} {} {}'.format(userId.replace('fakeUser', ''), itemId, i[2]) + '\n'
        
#         ratingText.append(new_line)
#         if "fakeUser" in userId:
#             fake.append(f"{userId.replace('fakeUser', '')} 1\n")
#         else:
#             normal.append(f"{userId} 0\n")
#     fake = list(set(fake))
#     normal = list(set(normal))
#     with open(fileName + "ratings.txt", 'w') as f:
#         f.writelines(ratingText)

#     # Shuffle normal and fake data randomly
#     random.shuffle(normal)
#     random.shuffle(fake)

#     # Split data into train, test, and validation sets
#     train_size_normal = int(len(normal) * 0.6)
#     test_size_normal = int(len(normal) * 0.2)
#     val_size_normal = len(normal) - train_size_normal - test_size_normal

#     train_size_fake = int(len(fake) * 0.6)
#     test_size_fake = int(len(fake) * 0.2)
#     val_size_fake = len(fake) - train_size_fake - test_size_fake

#     # Create splits
#     train = normal[:train_size_normal] + fake[:train_size_fake]
#     test = normal[train_size_normal:train_size_normal + test_size_normal] + fake[train_size_fake:train_size_fake + test_size_fake]
#     val = normal[train_size_normal + test_size_normal:] + fake[train_size_fake + test_size_fake:]

#     # Save train, test, and validation sets
#     with open(fileName + 'train.txt', 'w') as f:
#         f.writelines(train)

#     with open(fileName + 'test.txt', 'w') as f:
#         f.writelines(test)

#     with open(fileName + 'val.txt', 'w') as f:
#         f.writelines(val)

    # train = normal[:int(len(normal) * 0.8)] + fake[:int(len(fake) * 0.8)]
    # test = normal[int(len(normal) * 0.8):int(len(normal) * 0.9)] + fake[int(len(fake) * 0.8):int(len(fake) * 0.9)]
    # val = normal[int(len(normal) * 0.9):] + fake[int(len(fake) * 0.9):]

    # with open(fileName + 'train.txt','w') as f:
    #     f.writelines(train)

    # with open(fileName + 'test.txt','w') as f:
    #     f.writelines(test)

    # with open(fileName + 'val.txt','w') as f:
    #     f.writelines(val)
        
def detectDataSave_timestamp(ratings_list, fileName, id2user, id2item):
    """
    专门用于保存带时间戳的 List 格式数据的检测集生成函数
    :param ratings_list: list of [u_internal, i_internal, rating, timestamp]
    :param fileName: str, 保存路径
    :param id2user: dict
    :param id2item: dict
    """
    if not os.path.exists(fileName):
        os.makedirs(fileName)

    ratingText = []
    normal = []
    fake = []

    # 直接遍历列表，不再需要 nonzero()
    for row in ratings_list:
        u_internal = row[0]
        i_internal = row[1]
        rating = row[2]
        timestamp = row[3]  # 获取时间戳

        # 1. 还原 User ID
        if u_internal in id2user.keys():
            userId = id2user[u_internal]
            is_fake = False
        else:
            userId = "fakeUser" + str(u_internal)
            is_fake = True

        # 2. 还原 Item ID
        itemId = id2item[i_internal]

        # 3. 生成 ratings.txt 内容
        # 为了保持检测数据的真实性，这里去掉 'fakeUser' 前缀
        # 既然是专门的 timestamp 版本，建议把 timestamp 也写入 ratings.txt
        clean_uid = userId.replace('fakeUser', '') if is_fake else userId
        
        # 格式: User Item Rating Timestamp
        new_line = '{} {} {} {}'.format(clean_uid, itemId, int(rating), timestamp) + '\n'
        ratingText.append(new_line)

        # 4. 生成标签数据 (用于检测模型的训练)
        if is_fake:
            fake.append(f"{clean_uid} 1\n") # 1 表示攻击用户
        else:
            normal.append(f"{userId} 0\n")  # 0 表示正常用户

    # 去重标签数据
    fake = list(set(fake))
    normal = list(set(normal))

    # 保存完整的 ratings.txt
    with open(fileName + "ratings.txt", 'w') as f:
        f.writelines(ratingText)

    # ---------------------------------------------------------
    # 下面是数据集切分逻辑 (保持原样)
    # ---------------------------------------------------------
    random.shuffle(normal)
    random.shuffle(fake)

    # 6:2:2 切分
    train_size_normal = int(len(normal) * 0.6)
    test_size_normal = int(len(normal) * 0.2)
    
    train_size_fake = int(len(fake) * 0.6)
    test_size_fake = int(len(fake) * 0.2)

    # 构建数据集
    train = normal[:train_size_normal] + fake[:train_size_fake]
    test = normal[train_size_normal:train_size_normal + test_size_normal] + \
           fake[train_size_fake:train_size_fake + test_size_fake]
    val = normal[train_size_normal + test_size_normal:] + \
          fake[train_size_fake + test_size_fake:]

    # 保存 Train/Test/Val
    with open(fileName + 'train.txt', 'w') as f:
        f.writelines(train)

    with open(fileName + 'test.txt', 'w') as f:
        f.writelines(test)

    with open(fileName + 'val.txt', 'w') as f:
        f.writelines(val)

import os
import numpy as np
import random

def targetItemSelect(data, arg, popularThreshold=0.1):
    interact = data.matrix()
    userNum = interact.shape[0]
    itemNum = interact.shape[1]
    targetSize = arg.targetSize
    if targetSize < 1:
        targetNum = int(targetSize * itemNum)
    else:
        targetNum = int(targetSize)
        
    # 建议加上 args.dataset 防止跨数据集读取错误缓存
    path = './data/clean/' + data.dataName + "/" + "targetItem_" + arg.attackTargetChooseWay + "_" + str(
        targetNum) + ".txt"

    # === 修改部分开始：尝试读取缓存并校验 ===
    if os.path.exists(path):
        try:
            with open(path, 'r') as f:
                line = f.read()
                # 1. 读取并去除空格/引号
                cached_items = [i.replace("'", "").strip() for i in line.split(",")]
            
            # 2. 核心校验：只保留在当前 data.item 中存在的 ID
            targetItem = [i for i in cached_items if i in data.item]
            
            # 3. 判断：如果过滤后的数量 == 缓存数量（说明全是合法的），且数量足够，则直接返回
            if len(targetItem) == len(cached_items) and len(targetItem) >= targetNum:
                return targetItem[:targetNum]
            else:
                print(f"[Warning] 缓存失效：发现 {len(cached_items) - len(targetItem)} 个非法/被过滤的物品，正在重新生成...")
                # 注意：这里不 return，让代码继续向下走，去执行生成逻辑
        except Exception as e:
            print(f"[Warning] 读取缓存出错 ({e})，正在重新生成...")
    # === 修改部分结束 ===

    # 下面的代码去掉了 'else:' 缩进，作为默认的生成逻辑
    
    def getPopularItemId(n):
        """
        Get the id of the top n popular items based on the number of ratings
        :return: id list
        """
        # 加上 .flatten() 防止矩阵维度问题
        return np.argsort(np.array(interact[:, :].sum(0)).flatten())[-n:].tolist()

    def getReversePopularItemId(n):
        """
        Get the ids of the top n unpopular items based on the number of ratings
        :return: id list
        """
        return np.argsort(np.array(interact[:, :].sum(0)).flatten())[:n].tolist()

    if arg.attackTargetChooseWay == "random":
        targetItem = random.sample(list(range(itemNum)),
                                   targetNum)
    elif arg.attackTargetChooseWay == "popular":
        targetItem = random.sample(list(set(getPopularItemId(int(popularThreshold * itemNum)))),
                                   targetNum)
    elif arg.attackTargetChooseWay == "unpopular":
        targetItem = random.sample(
            list(set(getReversePopularItemId(int(0.2 * itemNum)))),
            targetNum)

    # 将 Internal ID 转为 Token ID
    targetItem = [data.id2item[i] for i in targetItem]
    
    # 保存新文件
    with open(path, 'w') as f:
        f.writelines(str(targetItem).replace('[', '').replace(']', ''))
        
    return targetItem
def seedSet(seed):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False