#!/usr/bin/env python3
"""Cross-user Skill Transfer experiment for CRAFTS/AFL_v5.

The experiment keeps the existing ARS, SkillDesigner, SkillRouter, trajectory
collection, and Skill Bank evolution implementations unchanged.  The existing
trained retriever is deliberately frozen, so no retriever optimizer/loss step
is executed.  The experiment changes which users are visible to Skill Bank
construction:

* train/valid atomic files contain training users only;
* the test atomic file contains unseen users only;
* CrossUserARS._get_train_users() is restricted by train_users.json;
* the existing Qwen3-4B SFT adapter and existing trained retriever are frozen;
* w/o Skill and CRAFTS use the exact same held-out users and candidates;
* the held-out Skill Bank is frozen before unseen-user evaluation.

Use ``--schedule`` for a long-running GPU-aware queue, or ``--worker`` to run a
single dataset directly.  The scheduler is designed to itself be launched via
nohup.
"""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import random
import shutil
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path
from types import MethodType
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_PYTHON = Path("/home/fengjiayin/.conda/envs/rs_new2/bin/python")
BACKBONE = Path("/home/fengjiayin/Qwen/Qwen3-4B")
DEFAULT_RESULT_ROOT = PROJECT_ROOT / "results/cross_user_transfer"

DATASETS = {
    "lastfm": {
        "dataset_arg": "lastfm",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_lastfm_lora",
        "designer_variant": "lastfm",
        "retriever": PROJECT_ROOT / "skills-ls/retriever/projector.pt",
    },
    "movielens": {
        "dataset_arg": "ml100k",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_ml_lora",
        "designer_variant": "generic",
        "retriever": PROJECT_ROOT / "skills-ml100k/retriever/projector.pt",
    },
    "instruments": {
        "dataset_arg": "Instruments",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_in_lora",
        "designer_variant": "instruments",
        "retriever": PROJECT_ROOT / "skills/retriever/projector.pt",
    },
}


def _atomic_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _atomic_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sort_token(value: str):
    text = str(value)
    return (0, int(text)) if text.isdigit() else (1, text)


def _read_raw_interactions(path: Path) -> list[tuple[str, str, float, float]]:
    with path.open("r", encoding="utf-8") as handle:
        columns = handle.readline().rstrip("\n").split("\t")
        fields = [column.split(":", 1)[0] for column in columns]
        user_idx = fields.index("user_id")
        item_idx = fields.index("item_id")
        rating_idx = fields.index("rating") if "rating" in fields else None
        time_idx = fields.index("timestamp") if "timestamp" in fields else None
        rows = []
        for line in handle:
            values = line.rstrip("\n").split("\t")
            if len(values) <= max(user_idx, item_idx):
                continue
            rating = float(values[rating_idx]) if rating_idx is not None and values[rating_idx] else 1.0
            timestamp = float(values[time_idx]) if time_idx is not None and values[time_idx] else 0.0
            rows.append((str(values[user_idx]), str(values[item_idx]), rating, timestamp))
    return rows


def _write_atomic_inter(path: Path, rows: Iterable[tuple[str, str, float, float, list[str]]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        handle.write(
            "user_id:token\titem_id:token\trating:float\ttimestamp:float\titem_id_list:token_seq\n"
        )
        for user, item, rating, timestamp, history in rows:
            handle.write(
                f"{user}\t{item}\t{float(rating)}\t{float(timestamp)}\t{' '.join(history)}\n"
            )


def _build_candidates(
    test_rows: list[tuple[str, str, float, float, list[str]]],
    grouped: dict[str, list[tuple[str, str, float, float]]],
    seed: int,
    candidate_count: int = 20,
) -> dict[str, list[str]]:
    rng = random.Random(seed)
    all_items = sorted({row[1] for rows in grouped.values() for row in rows}, key=_sort_token)
    candidates = {}
    for user, ground_truth, _, _, _ in test_rows:
        forbidden = {row[1] for row in grouped[user]}
        pool = [item for item in all_items if item not in forbidden]
        negatives = rng.sample(pool, min(candidate_count - 1, len(pool)))
        row = [ground_truth] + negatives
        rng.shuffle(row)
        candidates[str(user)] = row
    return candidates


def _read_atomic_users(path: Path) -> set[str]:
    users = set()
    with path.open("r", encoding="utf-8") as handle:
        columns = handle.readline().rstrip("\n").split("\t")
        user_idx = [column.split(":", 1)[0] for column in columns].index("user_id")
        for line in handle:
            values = line.rstrip("\n").split("\t")
            if len(values) > user_idx:
                users.add(str(values[user_idx]))
    return users


def _select_evaluation_users(
    dataset_root: Path,
    test_users: list,
    seed: int,
    test_limit: int,
) -> tuple[list[str], Path]:
    """Persist the exact deterministic unseen-user subset used for evaluation."""
    users = list(map(str, test_users))
    if test_limit > 0 and test_limit < len(users):
        selected = random.Random(seed).sample(users, test_limit)
        selected = sorted(selected, key=_sort_token)
    else:
        selected = users
    json_path = dataset_root / "evaluated_test_users.json"
    text_path = dataset_root / "evaluated_test_users.txt"
    _atomic_json(json_path, selected)
    _atomic_text(text_path, "".join(f"{user}\n" for user in selected))
    return selected, text_path


def _select_eval_user_shard(
    dataset_root: Path,
    selected_users: list[str],
    num_shards: int,
    shard_index: int,
) -> tuple[list[str], Path]:
    if num_shards <= 1:
        return selected_users, dataset_root / "evaluated_test_users.txt"
    if shard_index < 0 or shard_index >= num_shards:
        raise ValueError("--shard-index must be in [0, --num-shards)")
    shard_users = [
        user for idx, user in enumerate(selected_users) if idx % num_shards == shard_index
    ]
    shard_tag = f"shard_{shard_index:02d}_of_{num_shards:02d}"
    json_path = dataset_root / f"evaluated_test_users_{shard_tag}.json"
    text_path = dataset_root / f"evaluated_test_users_{shard_tag}.txt"
    _atomic_json(json_path, shard_users)
    _atomic_text(text_path, "".join(f"{user}\n" for user in shard_users))
    return shard_users, text_path


def prepare_user_level_split(
    dataset_key: str,
    output_root: Path,
    train_ratio: float,
    seed: int,
    min_interactions: int,
    max_history: int,
) -> dict:
    cfg = DATASETS[dataset_key]
    dataset = cfg["dataset_arg"]
    source_dir = PROJECT_ROOT / "data/clean" / dataset
    source_inter = source_dir / f"{dataset}.inter"
    source_item = source_dir / f"{dataset}.item"
    if not source_inter.is_file() or not source_item.is_file():
        raise FileNotFoundError(f"Missing source dataset files under {source_dir}")

    dataset_root = output_root / dataset_key
    data_parent = dataset_root / "data/clean"
    target_dir = data_parent / dataset
    model_root = dataset_root / "modelsaved"
    target_dir.mkdir(parents=True, exist_ok=True)
    model_root.mkdir(parents=True, exist_ok=True)

    grouped = defaultdict(list)
    for row in _read_raw_interactions(source_inter):
        grouped[row[0]].append(row)
    eligible = sorted(
        [user for user, rows in grouped.items() if len(rows) >= min_interactions],
        key=_sort_token,
    )
    if len(eligible) < 2:
        raise RuntimeError(f"{dataset}: fewer than two eligible users")

    shuffled = list(eligible)
    random.Random(seed).shuffle(shuffled)
    train_count = int(len(shuffled) * train_ratio)
    train_count = min(max(1, train_count), len(shuffled) - 1)
    train_users = sorted(shuffled[:train_count], key=_sort_token)
    test_users = sorted(shuffled[train_count:], key=_sort_token)
    train_set, test_set = set(train_users), set(test_users)
    if train_set & test_set:
        raise RuntimeError("User-level split overlap detected")

    train_rows = []
    valid_rows = []
    test_rows = []
    for user in eligible:
        interactions = sorted(grouped[user], key=lambda row: (row[3], _sort_token(row[1])))
        items = [row[1] for row in interactions]
        if user in train_set:
            last_train_target = len(interactions) - 3
            for target_idx in range(1, last_train_target + 1):
                target = interactions[target_idx]
                history = items[:target_idx][-max_history:]
                if history:
                    train_rows.append((user, target[1], target[2], target[3], history))
            valid_idx = len(interactions) - 2
            target = interactions[valid_idx]
            valid_rows.append((user, target[1], target[2], target[3], items[:valid_idx][-max_history:]))
        elif user in test_set:
            target_idx = len(interactions) - 1
            target = interactions[target_idx]
            test_rows.append((user, target[1], target[2], target[3], items[:target_idx][-max_history:]))

    train_path = target_dir / f"{dataset}.train.inter"
    valid_path = target_dir / f"{dataset}.valid.inter"
    test_path = target_dir / f"{dataset}.test.inter"
    _write_atomic_inter(train_path, train_rows)
    _write_atomic_inter(valid_path, valid_rows)
    _write_atomic_inter(test_path, test_rows)
    shutil.copy2(source_item, target_dir / source_item.name)

    candidates = _build_candidates(test_rows, grouped, seed=seed)
    candidate_path = model_root / "ARS" / dataset / "candidates.json"
    _atomic_json(candidate_path, candidates)
    _atomic_json(dataset_root / "train_users.json", train_users)
    _atomic_json(dataset_root / "test_users.json", test_users)

    observed_train = _read_atomic_users(train_path)
    observed_valid = _read_atomic_users(valid_path)
    observed_test = _read_atomic_users(test_path)
    if not observed_train <= train_set or not observed_valid <= train_set:
        raise RuntimeError("Unseen users leaked into train/valid atomic files")
    if observed_test != test_set:
        raise RuntimeError("Test atomic users do not exactly match test_users.json")
    if set(candidates) != test_set:
        raise RuntimeError("Candidate users do not exactly match unseen test users")

    manifest = {
        "experiment": "cross_user_skill_transfer",
        "dataset": dataset_key,
        "dataset_arg": dataset,
        "source_inter": str(source_inter),
        "source_inter_sha256": _sha256(source_inter),
        "split_unit": "user",
        "split_ratio": {"train": train_ratio, "test": round(1.0 - train_ratio, 10)},
        "seed": seed,
        "min_interactions": min_interactions,
        "max_history": max_history,
        "eligible_user_num": len(eligible),
        "train_user_num": len(train_users),
        "test_user_num": len(test_users),
        "train_sample_num": len(train_rows),
        "valid_sample_num": len(valid_rows),
        "test_sample_num": len(test_rows),
        "train_test_overlap": 0,
        "data_path": str(data_parent),
        "model_root": str(model_root),
        "candidate_path": str(candidate_path),
    }
    _atomic_json(dataset_root / "split_manifest.json", manifest)
    return manifest


def _build_crafts_args(dataset_key: str, output_root: Path, seed: int, gpus: str, use_sft: bool = True):
    # Imports happen only after CUDA visibility is fixed by run_worker().
    from conf.agent_parser import agent_parse_args
    from conf.recommend_parser import recommend_parse_args

    cfg = DATASETS[dataset_key]
    dataset = cfg["dataset_arg"]
    dataset_root = output_root / dataset_key
    rec_args = recommend_parse_args()
    agent_args = agent_parse_args()

    rec_overrides = {
        "dataset": dataset,
        "data_path": str(dataset_root / "data/clean"),
        "model_type": "agent",
        "model_name": "ARS",
        "agent": True,
        "split_data": False,
        "topK": "1",
        "gpu_id": "0",
        "seed": seed,
        "save": True,
        "load": True,
        "save_dir": str(dataset_root / "modelsaved"),
    }
    agent_overrides = {
        "tool_name": "SASRec",
        "tool_type": "sequential",
        "config_file_path": str(PROJECT_ROOT / "tool_conf/default/SASRec.yaml"),
        "load_recommender": True,
        "agent": True,
        "use_candidate_prior": True,
        "candidate_generate_mode": "random",
        "agent_workers": 1,
        "model": "Qwen3-4B",
        "local_model_path": str(BACKBONE),
        "student_lora_path": str(cfg["adapter"]) if use_sft else "none",
        "test_only": False,
        "train_user_num": "all",
        "test_user_num": "all",
        "report_k": 1,
        "report_interval": 50,
        "max_epoch": 1,
        "temperature": 0.2,
        "enable_memskill": True,
        "skill_bank_path": str(dataset_root / "skill_bank"),
        "skill_designer_variant": cfg["designer_variant"],
        "retriever_checkpoint": str(cfg["retriever"]),
        "retriever_mode": "trainable",
        "user_skill_top_k": 2,
        "functional_skill_top_k": 2,
        "skill_similarity_threshold": 0.35,
        "test_skill_ablation": "none",
        "eval_output_dir": str(dataset_root / "evaluation"),
        "prompt_log_path": str(dataset_root / "evaluation/prompts.txt"),
        "skill_debug_dir": str(dataset_root / "skill_debug"),
        "debug_skill_prompts": False,
        "disable_skill_evolution": False,
        "user_skill_utilization_mode": "original",
        "gpu_assignment": gpus,
    }
    for key, value in rec_overrides.items():
        setattr(rec_args, key, value)
    for key, value in agent_overrides.items():
        setattr(agent_args, key, value)
    for key, value in vars(agent_args).items():
        setattr(rec_args, key, value)
    return rec_args, agent_args


def _install_safe_torch_load() -> None:
    import torch

    original_load = torch.load

    def safe_load(*args, **kwargs):
        kwargs.setdefault("weights_only", False)
        if not torch.cuda.is_available():
            kwargs.setdefault("map_location", torch.device("cpu"))
        return original_load(*args, **kwargs)

    torch.load = safe_load


def _update_global_results(output_root: Path, dataset_key: str, result: dict) -> None:
    summary_path = output_root / "cross_user_transfer_results.json"
    lock_path = output_root / ".results.lock"
    output_root.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        payload = {}
        if summary_path.is_file():
            existing = json.loads(summary_path.read_text(encoding="utf-8"))
            if isinstance(existing, dict):
                payload = existing
        payload[dataset_key] = result
        _atomic_json(summary_path, payload)


def _merge_method_result(output_root: Path, dataset_key: str, result: dict) -> None:
    """Atomically merge one independently evaluated method into result files."""
    dataset_path = output_root / dataset_key / "cross_user_transfer_results.json"
    lock_path = output_root / ".results.lock"
    output_root.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        rows = []
        if dataset_path.is_file():
            existing = json.loads(dataset_path.read_text(encoding="utf-8"))
            if isinstance(existing, list):
                rows = existing
        rows = [row for row in rows if row.get("method") != result["method"]]
        rows.append(result)
        order = {"w/o Skill": 0, "CRAFTS": 1}
        rows.sort(key=lambda row: order.get(row.get("method"), 99))
        _atomic_json(dataset_path, rows)

        summary_path = output_root / "cross_user_transfer_results.json"
        summary = {}
        if summary_path.is_file():
            existing = json.loads(summary_path.read_text(encoding="utf-8"))
            if isinstance(existing, dict):
                summary = existing
        summary[dataset_key] = rows
        _atomic_json(summary_path, summary)


def _read_jsonl(path: Path) -> list[dict]:
    rows = []
    if not path.is_file():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _concat_existing_files(inputs: list[Path], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    tmp = output.with_suffix(output.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as dst:
        for path in inputs:
            if not path.is_file():
                continue
            with path.open("r", encoding="utf-8") as src:
                shutil.copyfileobj(src, dst)
    os.replace(tmp, output)


def run_merge_shards(args) -> int:
    dataset_key = args.dataset
    output_root = Path(args.output_root).resolve()
    dataset_root = output_root / dataset_key
    manifest = json.loads((dataset_root / "split_manifest.json").read_text(encoding="utf-8"))
    train_users = json.loads((dataset_root / "train_users.json").read_text(encoding="utf-8"))
    test_users = json.loads((dataset_root / "test_users.json").read_text(encoding="utf-8"))
    eval_users, _ = _select_evaluation_users(dataset_root, test_users, args.seed, args.test_limit)

    enable_skills = args.method == "crafts"
    use_sft = not args.no_sft
    method_name = "CRAFTS" if enable_skills else "w/o Skill"
    directory_name = "crafts" if enable_skills else "wo_skill"
    shard_root = dataset_root / "evaluation" / f"{directory_name}_shards"
    shard_dirs = [
        shard_root / f"shard_{idx:02d}_of_{args.num_shards:02d}"
        for idx in range(args.num_shards)
    ]
    missing = [
        str(path / "final_metrics.json")
        for path in shard_dirs
        if not (path / "final_metrics.json").is_file()
    ]
    if missing:
        raise FileNotFoundError(f"Cannot merge incomplete shards: {missing}")

    metrics_rows = [
        json.loads((path / "final_metrics.json").read_text(encoding="utf-8"))
        for path in shard_dirs
    ]
    processed = sum(int(row.get("num_test_samples", row.get("processed_users", 0))) for row in metrics_rows)
    hits = sum(int(row.get("hits_at_1", 0)) for row in metrics_rows)
    parse_success = sum(int(row.get("parse_success_count", 0)) for row in metrics_rows)
    parse_failure = sum(int(row.get("parse_failure_count", 0)) for row in metrics_rows)
    errors = sum(int(row.get("error_count", 0)) for row in metrics_rows)
    if processed != len(eval_users):
        raise RuntimeError(f"Merged shards cover {processed} users, expected {len(eval_users)}")

    eval_dir = dataset_root / "evaluation" / directory_name
    eval_dir.mkdir(parents=True, exist_ok=True)
    for filename in (
        "inference_results.jsonl",
        "incorrect_recommendations.jsonl",
        "errors.jsonl",
        "skill_retrieval.jsonl",
        "prompts.txt",
        "nohup.log",
    ):
        _concat_existing_files([path / filename for path in shard_dirs], eval_dir / filename)

    template = dict(metrics_rows[0])
    template.update({
        "stage": "test",
        "ts": int(time.time()),
        "processed_users": processed,
        "hr_at_k": hits / processed if processed else 0.0,
        "h1": hits / processed if processed else 0.0,
        "hits_at_1": hits,
        "num_test_samples": processed,
        "parse_success_count": parse_success,
        "parse_failure_count": parse_failure,
        "error_count": errors,
        "merged_from_shards": args.num_shards,
        "shard_metric_paths": [str(path / "final_metrics.json") for path in shard_dirs],
    })
    if "overall_topk_metrics" in template and parse_success:
        score = hits / parse_success
        template["overall_topk_metrics"] = {
            "topk": [1],
            "num_eval_users": parse_success,
            "precision": [score],
            "hr": [score],
            "recall": [score],
            "ndcg": [score],
        }
    _atomic_json(eval_dir / "final_metrics.json", template)

    cfg = DATASETS[dataset_key]
    bank_path = dataset_root / "skill_bank" / "skill_bank.json"
    result = {
        "dataset": dataset_key,
        "split_ratio": manifest["split_ratio"],
        "seed": int(manifest["seed"]),
        "train_user_num": len(train_users),
        "test_user_num": len(eval_users),
        "total_unseen_test_user_num": len(test_users),
        "method": method_name,
        "HR@1": float(template["h1"]),
        "num_test_samples": int(template["num_test_samples"]),
        "model_name": "Qwen3-4B" if use_sft else "Qwen3-4B-base",
        "sft_adapter": str(cfg["adapter"]) if use_sft else None,
        "use_sft": use_sft,
        "retriever_checkpoint": str(cfg["retriever"]),
        "skill_bank_path": str(bank_path) if enable_skills else None,
        "skill_bank_sha256": _sha256(bank_path) if enable_skills else None,
        "unseen_users_in_skill_bank_construction": 0,
        "retriever_frozen": True,
        "gpu_assignment": "sharded",
        "merged_from_shards": args.num_shards,
    }
    _atomic_json(eval_dir / "method_result.json", result)
    _merge_method_result(output_root, dataset_key, result)
    _atomic_json(eval_dir / "phase_status.json", {
        "phase": "complete",
        "updated_at": int(time.time()),
        "method": method_name,
        "merged_from_shards": args.num_shards,
    })
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 0


def run_eval_worker(args) -> int:
    """Evaluate one method without entering construction/evolution/training paths."""
    dataset_key = args.dataset
    output_root = Path(args.output_root).resolve()
    dataset_root = output_root / dataset_key
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpus)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ.setdefault("CRAFTS_SHARE_FROZEN_RETRIEVER", "1")
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
    if "," in str(args.gpus):
        os.environ.setdefault("CRAFTS_DEVICE_MAP", "balanced")

    manifest_path = dataset_root / "split_manifest.json"
    train_users_path = dataset_root / "train_users.json"
    test_users_path = dataset_root / "test_users.json"
    if not all(path.is_file() for path in (manifest_path, train_users_path, test_users_path)):
        raise FileNotFoundError(f"Prepared user-level split is missing under {dataset_root}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    train_users = json.loads(train_users_path.read_text(encoding="utf-8"))
    test_users = json.loads(test_users_path.read_text(encoding="utf-8"))
    if set(map(str, train_users)) & set(map(str, test_users)):
        raise RuntimeError("User-level split overlap detected in eval worker")
    eval_users, eval_user_file = _select_evaluation_users(
        dataset_root, test_users, args.seed, args.test_limit
    )
    full_eval_users = list(eval_users)
    eval_users, eval_user_file = _select_eval_user_shard(
        dataset_root, full_eval_users, args.num_shards, args.shard_index
    )

    cfg = DATASETS[dataset_key]
    dataset = cfg["dataset_arg"]
    save_root = dataset_root / "modelsaved" / "ARS" / dataset
    required = [
        BACKBONE / "config.json",
        cfg["retriever"],
        save_root / "candidates.json",
        save_root / "clean/prior_csv/SASRec.csv",
        save_root / "clean/tool/SASRec_model.pth",
    ]
    use_sft = not args.no_sft
    if use_sft:
        required.append(cfg["adapter"] / "adapter_config.json")

    enable_skills = args.method == "crafts"
    method_name = "CRAFTS" if enable_skills else "w/o Skill"
    directory_name = "crafts" if enable_skills else "wo_skill"
    if enable_skills:
        skill_bank_dir = dataset_root / "skill_bank"
        required.append(skill_bank_dir / "skill_bank.json")
    else:
        # ARS's frozen test loader validates a manifest even when skill routing is
        # disabled.  Keep this empty bank isolated from the training-user bank.
        skill_bank_dir = dataset_root / "evaluation/wo_skill/empty_skill_bank"
        empty_manifest = skill_bank_dir / "skill_bank.json"
        if not empty_manifest.is_file():
            _atomic_json(empty_manifest, {
                "dataset_scope": dataset,
                "user_skills": [],
                "functional_skills": [],
            })
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing frozen evaluation assets: {missing}")

    if args.num_shards > 1:
        shard_tag = f"shard_{args.shard_index:02d}_of_{args.num_shards:02d}"
        eval_dir = dataset_root / "evaluation" / f"{directory_name}_shards" / shard_tag
    else:
        shard_tag = None
        eval_dir = dataset_root / "evaluation" / directory_name
    eval_dir.mkdir(parents=True, exist_ok=True)
    metrics_path = eval_dir / "final_metrics.json"
    if metrics_path.is_file():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        if int(metrics.get("num_test_samples", -1)) == len(eval_users):
            print(f"[CrossUserTransfer] Reusing completed method={method_name}", flush=True)
        else:
            metrics = None
    else:
        metrics = None

    if metrics is None:
        _install_safe_torch_load()
        from ARLib import ARLib
        from recommender.agent.ARS import ARS
        from util.DataLoader import DataLoader_recbole
        from util.tool import seedSet

        rec_args, agent_args = _build_crafts_args(
            dataset_key, output_root, args.seed, args.gpus, use_sft=use_sft
        )
        for target in (rec_args, agent_args):
            target.test_only = True
            target.enable_memskill = enable_skills
            target.skill_bank_path = str(skill_bank_dir)
            target.eval_output_dir = str(eval_dir)
            target.prompt_log_path = str(eval_dir / "prompts.txt")
            target.test_user_num = "all"
            target.test_user_file = str(eval_user_file)
        seedSet(args.seed)
        data = DataLoader_recbole(rec_args)
        model = ARS(rec_args, data)
        coordinator = ARLib(model, rec_args, agent_args)
        with open(os.devnull, "w", encoding="utf-8") as sink:
            with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
                coordinator.PrepareForTest()
                coordinator.RecommendTest()
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))

    if int(metrics.get("num_test_samples", -1)) != len(eval_users):
        raise RuntimeError(
            f"{method_name}: expected {len(eval_users)} unseen samples, "
            f"got {metrics.get('num_test_samples')}"
        )
    bank_path = skill_bank_dir / "skill_bank.json"
    result = {
        "dataset": dataset_key,
        "split_ratio": manifest["split_ratio"],
        "seed": int(manifest["seed"]),
        "train_user_num": len(train_users),
        "test_user_num": len(eval_users),
        "total_unseen_test_user_num": len(test_users),
        "total_evaluated_test_user_num": len(full_eval_users),
        "method": method_name,
        "HR@1": float(metrics.get("h1", metrics.get("hr_at_k", 0.0))),
        "num_test_samples": int(metrics["num_test_samples"]),
        "model_name": "Qwen3-4B" if use_sft else "Qwen3-4B-base",
        "sft_adapter": str(cfg["adapter"]) if use_sft else None,
        "use_sft": use_sft,
        "retriever_checkpoint": str(cfg["retriever"]),
        "skill_bank_path": str(bank_path) if enable_skills else None,
        "skill_bank_sha256": _sha256(bank_path) if enable_skills else None,
        "unseen_users_in_skill_bank_construction": 0,
        "retriever_frozen": True,
        "gpu_assignment": str(args.gpus),
    }
    if shard_tag is not None:
        result.update({
            "shard_index": args.shard_index,
            "num_shards": args.num_shards,
            "shard_tag": shard_tag,
        })
    _atomic_json(eval_dir / "method_result.json", result)
    if shard_tag is None:
        _merge_method_result(output_root, dataset_key, result)
    _atomic_json(eval_dir / "phase_status.json", {
        "phase": "complete",
        "updated_at": int(time.time()),
        "method": method_name,
        "shard_tag": shard_tag,
    })
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    return 0


def run_worker(args) -> int:
    dataset_key = args.dataset
    output_root = Path(args.output_root).resolve()
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpus)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    os.environ.setdefault("CRAFTS_SHARE_FROZEN_RETRIEVER", "1")
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
    if "," in str(args.gpus):
        os.environ.setdefault("CRAFTS_DEVICE_MAP", "balanced")

    manifest = prepare_user_level_split(
        dataset_key=dataset_key,
        output_root=output_root,
        train_ratio=args.train_ratio,
        seed=args.seed,
        min_interactions=args.min_interactions,
        max_history=args.max_history,
    )
    if args.prepare_only:
        print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)
        return 0

    cfg = DATASETS[dataset_key]
    required = [
        BACKBONE / "config.json",
        cfg["adapter"] / "adapter_config.json",
        cfg["retriever"],
        Path(manifest["candidate_path"]),
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing required assets: {missing}")

    _install_safe_torch_load()
    from ARLib import ARLib
    from recommender.agent.ARS import ARS
    from util.DataLoader import DataLoader_recbole
    from util.tool import seedSet

    rec_args, agent_args = _build_crafts_args(dataset_key, output_root, args.seed, args.gpus)
    seedSet(args.seed)
    data = DataLoader_recbole(rec_args)
    train_users = json.loads((output_root / dataset_key / "train_users.json").read_text(encoding="utf-8"))
    test_users = json.loads((output_root / dataset_key / "test_users.json").read_text(encoding="utf-8"))
    train_set, test_set = set(map(str, train_users)), set(map(str, test_users))
    if train_set & test_set:
        raise RuntimeError("Manifest leakage detected before model construction")
    eval_users, eval_user_file = _select_evaluation_users(
        output_root / dataset_key, test_users, args.seed, args.test_limit
    )
    for target in (rec_args, agent_args):
        target.test_user_num = "all"
        target.test_user_file = str(eval_user_file)

    model = ARS(rec_args, data)
    model._cross_user_stage = "bootstrap"
    model._cross_user_completed = set()

    def restricted_train_users(self, limit=None):
        users = [user for user in train_users if str(user) in self.data.user]
        if self._cross_user_stage == "update" and self._cross_user_completed:
            users = [user for user in users if str(user) not in self._cross_user_completed]
        if limit is not None:
            users = users[: int(limit)]
        if set(map(str, users)) - train_set:
            raise RuntimeError("CrossUserARS returned a non-training user")
        print(f"[CrossUserTransfer] Training-time user boundary: {len(users)} users")
        return list(map(str, users))

    # Instance-level override keeps the original ARS implementation untouched while
    # enforcing the user boundary for bootstrap, evolution, retriever supervision,
    # and any optional trajectory-distillation method.
    model._get_train_users = MethodType(restricted_train_users, model)
    coordinator = ARLib(model, rec_args, agent_args)

    dataset_root = output_root / dataset_key
    phase_path = dataset_root / "phase_status.json"

    def write_phase(phase: str, **extra):
        _atomic_json(phase_path, {"phase": phase, "updated_at": int(time.time()), **extra})

    # The original bootstrap prints the entire growing history collection once
    # per user.  SkillDesigner consumes at most initial_user_skill_budget users,
    # so restricting enumeration to that same budget is semantically identical
    # while avoiding multi-gigabyte logs.
    original_train_user_num = rec_args.train_user_num
    rec_args.train_user_num = str(rec_args.initial_user_skill_budget)
    agent_args.train_user_num = rec_args.train_user_num
    write_phase("bootstrap_skill_bank")
    with open(os.devnull, "w", encoding="utf-8") as sink:
        with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            coordinator.RecommendTrain()
    rec_args.train_user_num = original_train_user_num
    agent_args.train_user_num = original_train_user_num
    print(
        f"[CrossUserTransfer] Bootstrap complete: "
        f"user_skills={len(model.skill_bank.user_skills)} "
        f"functional_skills={len(model.skill_bank.functional_skills)}",
        flush=True,
    )
    save_dir = Path(rec_args.save_dir) / "ARS" / rec_args.dataset / "clean"
    root_dir = Path(rec_args.save_dir) / "ARS" / rec_args.dataset
    print("[CrossUserTransfer] Running original Skill Bank evolution on training users only", flush=True)

    def keep_frozen_retriever(self, interaction_logs):
        users = {str(row.get("user_id")) for row in interaction_logs}
        leaked = users - train_set
        if leaked:
            raise RuntimeError(f"Trajectory supervision contains unseen users: {sorted(leaked)[:5]}")
        self.retrieval_interaction_logs = list(interaction_logs)
        print(
            f"[CrossUserTransfer] Frozen pretrained retriever retained: {cfg['retriever']} "
            f"(observed {len(users)} training users; no optimizer/loss step)",
            flush=True,
        )

    # Skill evolution and trajectory collection remain unchanged.  Only the
    # final retriever optimizer call is disabled because this evaluation uses
    # the already-trained retriever requested by the experiment setting.
    model._train_retriever_from_interaction_logs = MethodType(keep_frozen_retriever, model)
    retrieval_log = Path(model.retrieval_logs_path)
    if retrieval_log.is_file():
        for line in retrieval_log.read_text(encoding="utf-8").splitlines():
            if line.strip():
                model._cross_user_completed.add(str(json.loads(line).get("user_id")))
    model._cross_user_stage = "update"
    remaining_update_users = len(train_set - model._cross_user_completed)
    write_phase(
        "skill_bank_evolution",
        completed_training_users=len(model._cross_user_completed),
        remaining_training_users=remaining_update_users,
    )
    print(
        f"[CrossUserTransfer] Evolution resume: completed={len(model._cross_user_completed)} "
        f"remaining={remaining_update_users}",
        flush=True,
    )
    if remaining_update_users:
        with open(os.devnull, "w", encoding="utf-8") as sink:
            with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
                model.update_skill_bank_on_train(save_dir=str(save_dir), root_dir=str(root_dir))

    if retrieval_log.is_file():
        supervised_users = set()
        for line in retrieval_log.read_text(encoding="utf-8").splitlines():
            if line.strip():
                supervised_users.add(str(json.loads(line)["user_id"]))
        leaked = supervised_users - train_set
        if leaked:
            raise RuntimeError(f"Retriever supervision contains unseen users: {sorted(leaked)[:5]}")

    bank_path = Path(model.skill_bank.manifest_path)
    retriever_path = Path(cfg["retriever"])
    if not bank_path.is_file():
        raise FileNotFoundError(f"Skill Bank was not built: {bank_path}")
    if not retriever_path.is_file():
        raise FileNotFoundError(f"Frozen pretrained retriever is missing: {retriever_path}")
    bank_hash_before = _sha256(bank_path)

    results = []
    for method, enable_skills, directory_name in (
        ("w/o Skill", False, "wo_skill"),
        ("CRAFTS", True, "crafts"),
    ):
        method_dir = output_root / dataset_key / "evaluation" / directory_name
        method_dir.mkdir(parents=True, exist_ok=True)
        model.enable_memskill = enable_skills
        model.args.enable_memskill = enable_skills
        rec_args.enable_memskill = enable_skills
        agent_args.enable_memskill = enable_skills
        rec_args.eval_output_dir = str(method_dir)
        agent_args.eval_output_dir = str(method_dir)
        rec_args.prompt_log_path = str(method_dir / "prompts.txt")
        agent_args.prompt_log_path = str(method_dir / "prompts.txt")
        print(
            f"[CrossUserTransfer] Evaluating method={method} unseen_users={len(eval_users)} "
            f"(split_total={len(test_users)})",
            flush=True,
        )
        metrics_path = method_dir / "final_metrics.json"
        existing_metrics = None
        if metrics_path.is_file():
            candidate_metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            if int(candidate_metrics.get("num_test_samples", -1)) == len(eval_users):
                existing_metrics = candidate_metrics
                print(f"[CrossUserTransfer] Reusing completed method={method}", flush=True)
        if existing_metrics is None:
            write_phase("evaluation", method=method)
            with open(os.devnull, "w", encoding="utf-8") as sink:
                with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
                    coordinator.RecommendTest()
        if _sha256(bank_path) != bank_hash_before:
            raise RuntimeError(f"{method} evaluation mutated the frozen Skill Bank")
        metrics = existing_metrics or json.loads(metrics_path.read_text(encoding="utf-8"))
        if int(metrics.get("num_test_samples", -1)) != len(eval_users):
            raise RuntimeError(
                f"{method}: expected {len(eval_users)} unseen samples, "
                f"got {metrics.get('num_test_samples')}"
            )
        results.append({
            "dataset": dataset_key,
            "split_ratio": {"train": args.train_ratio, "test": round(1.0 - args.train_ratio, 10)},
            "seed": args.seed,
            "train_user_num": len(train_users),
            "test_user_num": len(eval_users),
            "total_unseen_test_user_num": len(test_users),
            "method": method,
            "HR@1": float(metrics.get("h1", metrics.get("hr_at_k", 0.0))),
            "num_test_samples": int(metrics["num_test_samples"]),
            "model_name": "Qwen3-4B",
            "sft_adapter": str(cfg["adapter"]),
            "retriever_checkpoint": str(retriever_path),
            "skill_bank_path": str(bank_path) if enable_skills else None,
            "skill_bank_sha256": bank_hash_before if enable_skills else None,
            "unseen_users_in_skill_bank_construction": 0,
            "retriever_frozen": True,
            "gpu_assignment": str(args.gpus),
        })
    dataset_result = output_root / dataset_key / "cross_user_transfer_results.json"
    _atomic_json(dataset_result, results)
    _update_global_results(output_root, dataset_key, results)
    write_phase("complete", result_path=str(dataset_result))
    print(json.dumps(results, ensure_ascii=False, indent=2), flush=True)
    return 0


def _gpu_status() -> dict[int, dict[str, int]]:
    completed = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,memory.total,memory.used,memory.free,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    status = {}
    for line in completed.stdout.splitlines():
        index, total, used, free, util = [int(value.strip()) for value in line.split(",")]
        if index in {0, 1}:
            status[index] = {"total": total, "used": used, "free": free, "util": util}
    return status


def _write_scheduler_state(output_root: Path, pending, running, completed, failed, gpu_status) -> None:
    _atomic_json(
        output_root / "scheduler_state.json",
        {
            "updated_at": int(time.time()),
            "pending": list(pending),
            "running": {name: info["gpus"] for name, info in running.items()},
            "completed": list(completed),
            "failed": failed,
            "gpu_status": gpu_status,
        },
    )


def run_scheduler(args) -> int:
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    if args.queue:
        pending = [name.strip() for name in args.queue.split(",") if name.strip()]
        unknown = [name for name in pending if name not in DATASETS]
        if unknown:
            raise ValueError(f"Unknown dataset(s) in --queue: {unknown}")
    else:
        pending = list(DATASETS) if args.dataset == "all" else [args.dataset]
    running = {}
    completed = []
    failed = {}
    python = str(Path(args.python).resolve())

    def launch(dataset_key: str, gpu_assignment: str):
        dataset_root = output_root / dataset_key
        dataset_root.mkdir(parents=True, exist_ok=True)
        log_path = dataset_root / "nohup.log"
        command = [
            python,
            str(PROJECT_ROOT / "run_cross_user_transfer.py"),
            "--worker",
            "--dataset", dataset_key,
            "--gpus", gpu_assignment,
            "--output-root", str(output_root),
            "--train-ratio", str(args.train_ratio),
            "--seed", str(args.seed),
            "--min-interactions", str(args.min_interactions),
            "--max-history", str(args.max_history),
        ]
        log_handle = log_path.open("a", encoding="utf-8")
        log_handle.write(f"\n[Scheduler] launch={time.time()} gpus={gpu_assignment} command={' '.join(command)}\n")
        log_handle.flush()
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = gpu_assignment
        env["HF_HUB_OFFLINE"] = "1"
        env["TRANSFORMERS_OFFLINE"] = "1"
        env["TOKENIZERS_PARALLELISM"] = "false"
        process = subprocess.Popen(
            command,
            cwd=PROJECT_ROOT,
            env=env,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        running[dataset_key] = {
            "process": process,
            "gpus": gpu_assignment,
            "log_handle": log_handle,
            "log_path": str(log_path),
        }
        print(f"[Scheduler] launched {dataset_key} pid={process.pid} GPUs={gpu_assignment}", flush=True)

    while pending or running:
        for dataset_key, info in list(running.items()):
            returncode = info["process"].poll()
            if returncode is None:
                continue
            info["log_handle"].close()
            del running[dataset_key]
            if returncode == 0:
                completed.append(dataset_key)
                print(f"[Scheduler] completed {dataset_key}", flush=True)
            else:
                failed[dataset_key] = returncode
                print(f"[Scheduler] failed {dataset_key} rc={returncode} log={info['log_path']}", flush=True)

        try:
            status = _gpu_status()
        except Exception as exc:
            print(f"[Scheduler] nvidia-smi unavailable: {exc}", flush=True)
            status = {}

        occupied = set()
        for info in running.values():
            occupied.update(int(value) for value in info["gpus"].split(","))
        available = [gpu for gpu in (0, 1) if gpu not in occupied and gpu in status]

        # Prefer one dataset per released card.  When neither card has enough
        # memory by itself and no experiment is running, use both cards jointly.
        individually_ready = [
            gpu for gpu in available
            if status[gpu]["free"] >= args.single_gpu_free_mib
            and status[gpu]["util"] <= args.max_gpu_util
        ]
        while pending and individually_ready:
            gpu = individually_ready.pop(0)
            launch(pending.pop(0), str(gpu))
        if pending and not running and set(available) == {0, 1}:
            combined_free = status[0]["free"] + status[1]["free"]
            minimum_each = min(status[0]["free"], status[1]["free"])
            if combined_free >= args.combined_gpu_free_mib and minimum_each >= args.combined_min_each_mib:
                launch(pending.pop(0), "0,1")

        _write_scheduler_state(output_root, pending, running, completed, failed, status)
        if pending or running:
            time.sleep(args.poll_seconds)

    return 1 if failed else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--worker", action="store_true", help="run one dataset")
    mode.add_argument("--eval-worker", action="store_true", help="evaluate one frozen method only")
    mode.add_argument("--merge-shards", action="store_true", help="merge completed eval shards")
    mode.add_argument("--schedule", action="store_true", help="GPU-aware dataset queue")
    parser.add_argument("--dataset", choices=[*DATASETS, "all"], default="all")
    parser.add_argument("--queue", default="", help="scheduler-only comma-separated dataset queue")
    parser.add_argument("--gpus", default="0,1", help="physical GPU IDs visible to one worker")
    parser.add_argument("--method", choices=["wo_skill", "crafts"], default="wo_skill")
    parser.add_argument("--output-root", default=str(DEFAULT_RESULT_ROOT))
    parser.add_argument("--train-ratio", type=float, default=0.8)
    parser.add_argument("--seed", type=int, default=2018)
    parser.add_argument("--min-interactions", type=int, default=5)
    parser.add_argument("--max-history", type=int, default=50)
    parser.add_argument(
        "--test-limit",
        type=int,
        default=0,
        help="deterministically evaluate at most this many unseen users (0 means all)",
    )
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--python", default=str(DEFAULT_PYTHON if DEFAULT_PYTHON.is_file() else Path(sys.executable)))
    parser.add_argument("--poll-seconds", type=int, default=60)
    parser.add_argument("--single-gpu-free-mib", type=int, default=7000)
    parser.add_argument("--combined-gpu-free-mib", type=int, default=9000)
    parser.add_argument("--combined-min-each-mib", type=int, default=3500)
    parser.add_argument("--max-gpu-util", type=int, default=60)
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--no-sft", action="store_true", help="use base Qwen3-4B without SFT LoRA adapter")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if not 0.0 < args.train_ratio < 1.0:
        raise ValueError("--train-ratio must be between 0 and 1")
    if args.worker:
        if args.dataset == "all":
            raise ValueError("--worker requires one concrete dataset")
        return run_worker(args)
    if args.eval_worker:
        if args.dataset == "all":
            raise ValueError("--eval-worker requires one concrete dataset")
        if args.num_shards < 1:
            raise ValueError("--num-shards must be >= 1")
        return run_eval_worker(args)
    if args.merge_shards:
        if args.dataset == "all":
            raise ValueError("--merge-shards requires one concrete dataset")
        if args.num_shards <= 1:
            raise ValueError("--merge-shards requires --num-shards > 1")
        return run_merge_shards(args)
    return run_scheduler(args)


if __name__ == "__main__":
    raise SystemExit(main())
