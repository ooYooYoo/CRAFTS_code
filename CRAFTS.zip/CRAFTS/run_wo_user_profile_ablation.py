#!/usr/bin/env python3
"""Run the frozen Qwen3-4B inference-time w/o User-profile Skills ablation."""

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_ROOT = PROJECT_ROOT / "outputs/ablation/qwen3_4b/wo_user_profile_inference"
BACKBONE = Path("/home/fengjiayin/Qwen/Qwen3-4B")
DEFAULT_PYTHON = Path("/home/fengjiayin/.conda/envs/rs_new2/bin/python")

DATASETS = {
    "lastfm": {
        "project_dataset": "lastfm",
        "output_name": "lastfm",
        "skill_bank": PROJECT_ROOT / "skills-ls",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_lastfm_lora",
    },
    "movielens": {
        "project_dataset": "ml100k",
        "output_name": "movielens",
        "skill_bank": PROJECT_ROOT / "skills-ml100k",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_ml_lora",
    },
    "instruments": {
        "project_dataset": "Instruments",
        "output_name": "instruments",
        "skill_bank": PROJECT_ROOT / "skills",
        "adapter": PROJECT_ROOT / "modelsaved/skill_student/qwen3_4b_in_lora",
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _build_instruments_manifest() -> Path:
    """Freeze the first 1,000 original test users without altering source data/candidates."""
    test_path = PROJECT_ROOT / "data/clean/Instruments/Instruments.test.inter"
    candidate_path = PROJECT_ROOT / "modelsaved/ARS/Instruments/candidates.json"
    manifest_dir = OUTPUT_ROOT / "instruments"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = manifest_dir / "test_users_1000.txt"
    provenance_path = manifest_dir / "test_users_1000_provenance.json"

    candidates = json.loads(candidate_path.read_text(encoding="utf-8"))
    with test_path.open("r", encoding="utf-8") as handle:
        header = handle.readline().rstrip("\n").split("\t")
        user_index = [column.split(":", 1)[0] for column in header].index("user_id")
        ordered_users = []
        for line in handle:
            columns = line.rstrip("\n").split("\t")
            user_id = columns[user_index]
            if user_id in candidates:
                ordered_users.append(user_id)

    selected = ordered_users[:1000]
    if len(selected) != 1000 or len(set(selected)) != 1000:
        raise RuntimeError(f"Expected 1,000 unique Instruments users, got {len(selected)}")
    manifest_path.write_text("\n".join(selected) + "\n", encoding="utf-8")
    provenance = {
        "selection": "first 1000 users in the existing Instruments.test.inter order that have original candidates",
        "source_test_file": str(test_path),
        "source_test_sha256": _sha256(test_path),
        "source_candidates_file": str(candidate_path),
        "source_candidates_sha256": _sha256(candidate_path),
        "count": len(selected),
        "manifest_sha256": _sha256(manifest_path),
        "note": "AFL_v5 had no pre-existing standalone 1000-user file; this manifest freezes the requested subset without changing source files.",
    }
    provenance_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest_path


def _validate_assets(dataset_key: str, config: dict) -> None:
    dataset = config["project_dataset"]
    required = [
        BACKBONE / "config.json",
        config["adapter"] / "adapter_config.json",
        config["skill_bank"] / "skill_bank.json",
        config["skill_bank"] / "retriever/projector.pt",
        PROJECT_ROOT / f"modelsaved/ARS/{dataset}/candidates.json",
        PROJECT_ROOT / f"modelsaved/ARS/{dataset}/clean/prior_csv/SASRec.csv",
        PROJECT_ROOT / f"modelsaved/ARS/{dataset}/clean/tool/SASRec_model.pth",
        PROJECT_ROOT / f"data/clean/{dataset}/{dataset}.test.inter",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"{dataset_key}: missing frozen assets: {missing}")


def _command(dataset_key: str, dry_run: bool, gpu_id: str, python_executable: str) -> tuple[list[str], Path]:
    config = DATASETS[dataset_key]
    dataset = config["project_dataset"]
    base_output = OUTPUT_ROOT / config["output_name"]
    output_dir = base_output / "dry_run" if dry_run else base_output
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        python_executable,
        "main.py",
        "--dataset", dataset,
        "--model_type", "agent",
        "--model_name", "ARS",
        "--agent", "True",
        "--test_only",
        "--split_data", "False",
        "--load_recommender", "True",
        "--candidate_generate_mode", "random",
        "--topK", "1",
        "--report_k", "1",
        "--gpu_id", gpu_id,
        "--seed", "2018",
        "--tool_type", "sequential",
        "--tool_name", "SASRec",
        "--agent_workers", "1",
        "--use_candidate_prior", "True",
        "--max_epoch", "1",
        "--temperature", "0.2",
        "--model", "Qwen3-4B",
        "--local_model_path", str(BACKBONE),
        "--student_lora_path", str(config["adapter"]),
        "--enable_memskill",
        "--skill_bank_path", str(config["skill_bank"]),
        "--retriever_checkpoint", str(config["skill_bank"] / "retriever/projector.pt"),
        "--user_skill_top_k", "2",
        "--functional_skill_top_k", "2",
        "--ablation_skill_top_k", "4",
        "--skill_similarity_threshold", "0.35",
        "--test_skill_ablation", "wo_user_profile",
        "--eval_output_dir", str(output_dir),
        "--ablation_dry_run", "True" if dry_run else "False",
        "--test_user_num", "5" if dry_run else "all",
        "--save_dir", str(PROJECT_ROOT / "modelsaved"),
    ]
    if dataset_key == "instruments":
        cmd.extend(["--test_user_file", str(_build_instruments_manifest())])
    return cmd, output_dir


def _update_summary() -> None:
    summary = {
        "variant": "w/o User-profile Skills at Inference",
        "backbone": "Qwen3-4B",
        "backbone_path": str(BACKBONE),
        "retrain_retriever": False,
        "retrain_rec_agent": False,
        "reuse_lora_adapter": True,
        "skill_pool": "functional_only",
        "lastfm_h1": None,
        "movielens_h1": None,
        "instruments_h1": None,
        "top_k": 4,
        "seed": 2018,
        "adapter": {key: str(value["adapter"]) for key, value in DATASETS.items()},
        "retriever_checkpoint": {
            key: str(value["skill_bank"] / "retriever/projector.pt") for key, value in DATASETS.items()
        },
    }
    for key, config in DATASETS.items():
        metrics_path = OUTPUT_ROOT / config["output_name"] / "eval_metrics/test_metrics_latest.json"
        if metrics_path.is_file():
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            summary[f"{config['output_name']}_h1"] = metrics.get("h1", metrics.get("hr_at_k"))
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (OUTPUT_ROOT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["lastfm", "movielens", "instruments", "all"], default="all")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--gpu-id", default="0")
    parser.add_argument(
        "--python",
        default=str(DEFAULT_PYTHON if DEFAULT_PYTHON.is_file() else Path(sys.executable)),
        help="Python executable with the original TraSkillRec environment",
    )
    parser.add_argument("--print-commands", action="store_true")
    args = parser.parse_args()

    selected = list(DATASETS) if args.dataset == "all" else [args.dataset]
    for dataset_key in selected:
        _validate_assets(dataset_key, DATASETS[dataset_key])
        cmd, output_dir = _command(dataset_key, args.dry_run, args.gpu_id, args.python)
        command_text = " ".join(cmd)
        print(f"[{dataset_key}] {command_text}", flush=True)
        if args.print_commands:
            continue
        log_path = output_dir / "run.log"
        with log_path.open("w", encoding="utf-8") as log_handle:
            completed = subprocess.run(
                cmd,
                cwd=PROJECT_ROOT,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                check=False,
                env=os.environ.copy(),
            )
        if completed.returncode != 0:
            raise SystemExit(f"{dataset_key} failed with exit code {completed.returncode}; see {log_path}")

    if not args.dry_run and not args.print_commands:
        _update_summary()


if __name__ == "__main__":
    main()
