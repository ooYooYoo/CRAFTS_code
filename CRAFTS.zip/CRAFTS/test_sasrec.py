import pandas as pd

def calculate_accuracy(csv_path, n_samples=None):
    try:
        # 读取 CSV 文件
        df = pd.read_csv(csv_path)
        
        # 如果指定了 n_samples，只取前 n_samples 个
        if n_samples is not None:
            df = df.head(n_samples)
            print(f"仅评估前 {n_samples} 个样本")
        
        # 检查必要的列是否存在
        required_columns = ['generate', 'real', 'generate_raw_item', 'real_raw_item']
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"CSV 文件缺少必要的列。需要包含: {required_columns}")

        total_samples = len(df)
        
        # 方式 1：基于物品 ID 计算准确率 (推荐，更严谨)
        # 判断生成的 ID 是否等于真实的 ID
        id_matches = df['generate_raw_item'] == df['real_raw_item']
        id_accuracy = id_matches.mean()
        
        # 方式 2：基于文本标题计算准确率
        # 转换为小写并去除两端空格，以减少格式导致的误判
        generate_text = df['generate'].astype(str).str.strip().str.lower()
        real_text = df['real'].astype(str).str.strip().str.lower()
        text_matches = generate_text == real_text
        text_accuracy = text_matches.mean()

        # 打印结果
        print("-" * 30)
        print(f"评估样本总数: {total_samples}")
        print(f"ID 匹配准确率 (HR@1): {id_accuracy:.4f} ({id_accuracy * 100:.2f}%)")
        print(f"文本匹配准确率:       {text_accuracy:.4f} ({text_accuracy * 100:.2f}%)")
        print("-" * 30)
        
        # 输出匹配成功的具体行（方便排查）
        if id_accuracy > 0:
            print("\n成功命中的样本:")
            print(df[id_matches][['user_id', 'generate', 'real']])
        else:
            print("\n未发现匹配的样本。")

        return id_accuracy

    except Exception as e:
        print(f"运行出错: {e}")

# 使用示例 - 只评估前 100 个样本
if __name__ == "__main__":
    calculate_accuracy('/home/fengjiayin/rs/AFL_v5/modelsaved/ARS/ml100k/clean/prior_csv/SASRec.csv')