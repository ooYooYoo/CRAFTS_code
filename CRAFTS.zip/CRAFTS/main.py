import os
import time
import warnings

import torch

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"

warnings.filterwarnings("ignore", category=UserWarning, module="torch._weights_only_unpickler")

_original_load = torch.load


def _safe_load(*args, **kwargs):
    if "weights_only" not in kwargs:
        kwargs["weights_only"] = False
    if not torch.cuda.is_available() and "map_location" not in kwargs:
        kwargs["map_location"] = torch.device("cpu")
    return _original_load(*args, **kwargs)


torch.load = _safe_load

from conf.agent_parser import agent_parse_args
from conf.recommend_parser import recommend_parse_args
from util.DataLoader import DataLoader
from util.tool import seedSet
from ARLib import ARLib


if __name__ == "__main__":
    # 1. parse args
    recommend_args = recommend_parse_args()
    agent_args = agent_parse_args()

    # merge agent args into recommend args
    for k, v in vars(agent_args).items():
        setattr(recommend_args, k, v)

    # 2. env / seed
    os.environ["CUDA_VISIBLE_DEVICES"] = str(recommend_args.gpu_id)
    seedSet(recommend_args.seed)

    # 3. import model class dynamically
    import_str = (
        "from recommender."
        + recommend_args.model_type
        + "."
        + recommend_args.model_name
        + " import "
        + recommend_args.model_name
    )
    exec(import_str)

    # 4. prepare data
    if recommend_args.agent and not recommend_args.test_only:
        print(f"[Main] Preparing dataset '{recommend_args.dataset}' for agent evaluation...")
        from util.DataLoader import DataLoader_recbole_Raw
        from util.split_data import BenchmarkSplitter

        raw_loader = DataLoader_recbole_Raw(recommend_args)
        splitter = BenchmarkSplitter(
            raw_loader=raw_loader,
            agent_args=agent_args,
            rec_args=recommend_args,
            dataset=recommend_args.dataset,
            agentname=recommend_args.model_name,
            save_dir=recommend_args.save_dir,
        )
        splitter.split_and_save()

        from util.DataLoader import DataLoader_recbole
        data = DataLoader_recbole(recommend_args)
    elif recommend_args.agent:
        print(f"[Main] Test-only mode: reusing existing benchmark files for '{recommend_args.dataset}'.")
        from util.DataLoader import DataLoader_recbole
        data = DataLoader_recbole(recommend_args)
    else:
        data = DataLoader(recommend_args)

    # 5. build model + coordinator
    recommend_model = eval(recommend_args.model_name)(recommend_args, data)
    arlib = ARLib(
        recommendModel=recommend_model,
        recommendArg=recommend_args,
        agentArg=agent_args,
    )

    # 6. run
    start = time.time()
    if recommend_args.test_only:
        arlib.PrepareForTest()
    else:
        arlib.RecommendTrain()
    arlib.RecommendTest()
    end = time.time()

    print("Running time: %f s" % (end - start))
