#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="/home/fengjiayin/rs/AFL_v5"
PYTHON_BIN="/home/fengjiayin/.conda/envs/rs_new2/bin/python"
RESULT_ROOT="${PROJECT_ROOT}/results/cross_user_transfer"
SEED="2018"
NUM_SHARDS="3"

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false
export CRAFTS_SHARE_FROZEN_RETRIEVER=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

cd "${PROJECT_ROOT}"

run_shard() {
  local dataset="$1"
  local shard_index="$2"
  local gpu="$3"
  local shard_tag
  shard_tag="$(printf 'shard_%02d_of_%02d' "${shard_index}" "${NUM_SHARDS}")"
  local log_dir="${RESULT_ROOT}/${dataset}/evaluation/crafts_shards/${shard_tag}"
  mkdir -p "${log_dir}"
  echo "[launcher] start dataset=${dataset} shard=${shard_tag} gpu=${gpu}"
  CUDA_VISIBLE_DEVICES="${gpu}" "${PYTHON_BIN}" "${PROJECT_ROOT}/run_cross_user_transfer.py" \
    --eval-worker \
    --dataset "${dataset}" \
    --method crafts \
    --gpus "${gpu}" \
    --output-root "${RESULT_ROOT}" \
    --seed "${SEED}" \
    --num-shards "${NUM_SHARDS}" \
    --shard-index "${shard_index}" \
    > "${log_dir}/nohup.log" 2>&1 &
}

pids=()

run_shard lastfm 0 1
pids+=("$!")
run_shard lastfm 1 1
pids+=("$!")
run_shard lastfm 2 0
pids+=("$!")
run_shard movielens 0 1
pids+=("$!")
run_shard movielens 1 1
pids+=("$!")
run_shard movielens 2 0
pids+=("$!")

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=1
  fi
done

if [[ "${failed}" -ne 0 ]]; then
  echo "[launcher] one or more shards failed; skip merge"
  exit 1
fi

echo "[launcher] all shards complete; merging lastfm"
"${PYTHON_BIN}" "${PROJECT_ROOT}/run_cross_user_transfer.py" \
  --merge-shards \
  --dataset lastfm \
  --method crafts \
  --output-root "${RESULT_ROOT}" \
  --seed "${SEED}" \
  --num-shards "${NUM_SHARDS}"

echo "[launcher] all shards complete; merging movielens"
"${PYTHON_BIN}" "${PROJECT_ROOT}/run_cross_user_transfer.py" \
  --merge-shards \
  --dataset movielens \
  --method crafts \
  --output-root "${RESULT_ROOT}" \
  --seed "${SEED}" \
  --num-shards "${NUM_SHARDS}"

echo "[launcher] done"
