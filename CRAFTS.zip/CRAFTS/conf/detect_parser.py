import argparse

def detect_parse_args():
    parser = argparse.ArgumentParser(description='Detect model parameter initialization')

    # ===== Genneral parameters ===== #
    parser.add_argument('--detectModelName', type=str, default="DHAGCN", metavar='N',help='')
    parser.add_argument('--times', type=int, default=1, metavar='N', help='the times of detect experiment')
    parser.add_argument('--detectDatasetPath', type=str, default="data/detect/douban_CompositeAttack_2025-11-10_21-11-43/1", metavar='N', help='the poisoning data sava path after attack.')
    parser.add_argument('--Epoch', type=int, default=50, metavar='N', help='optimzation epoch')
    args = parser.parse_args()
    return args

