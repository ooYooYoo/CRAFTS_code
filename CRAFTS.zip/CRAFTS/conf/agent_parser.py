import argparse


def str2bool(v):
    if isinstance(v, bool):
        return v
    if not isinstance(v, str):
        raise argparse.ArgumentTypeError("Boolean value expected.")
    value = v.lower()
    if value == "true":
        return True
    if value == "false":
        return False
    raise argparse.ArgumentTypeError("Boolean value expected.")



def agent_parse_args():
    """Parser for the refactored skill-centric recommendation pipeline.

    This version intentionally removes all RL / LoRA / self-distillation arguments.
    The workflow is:
    1) Train recommender/tool model
    2) Build initial skill bank from train user histories
    3) Run a second train pass with skills enabled and evolve the skill bank from failures
    4) Freeze the skill bank and evaluate on test data
    """

    parser = argparse.ArgumentParser(allow_abbrev=False)

    # ===== tool / recommender wrapper =====
    parser.add_argument("--tool_name", type=str, help="name of the tool model module")
    parser.add_argument("--tool_type", type=str, default="sequential", help="package/type of the tool model")
    parser.add_argument("--config_file_path", type=str, default=None, help="path to external config file for tool")
    parser.add_argument("--load_recommender", type=str2bool, default=True, help="load saved recommender artifacts")
    parser.add_argument("--MAX_ITEM_LIST_LENGTH", type=int, default=50, help="max interaction sequence length")
    parser.add_argument("--MIN_ITEM_LIST_LENGTH", type=int, default=5, help="min interaction sequence length")
    
    parser.add_argument("--rl_max_seq_len", type=int, default=1024, help="max token length per RL sample")

    # ===== agent =====
    # parser.add_argument("--api_key", type=str, default="", help="OpenAI / compatible API key")
    parser.add_argument("--model", type=str, default="Qwen3-8B", help="LLM model name")
    parser.add_argument("--agent", type=str2bool, default=True, help="whether to use agent recommender mode")
    parser.add_argument("--use_candidate_prior", type=str2bool, default=True, help="whether to generate prior with candidates")
    parser.add_argument(
        "--candidate_generate_mode",
        type=str,
        default="random",
        help="candidate generation mode: random, tool, or tool_shuffle",
    )
    parser.add_argument("--agent_workers", type=int, default=4, help="number of agent worker threads for test stage")
    parser.add_argument("--local_model_path", type=str, default="/home/fengjiayin/Qwen/Qwen3-8B", help="local model path")
    parser.add_argument("--train_user_num", type=str, default="all", help="users used for train-stage skill initialization/update")
    parser.add_argument("--test_user_num", type=str, default="all", help="users used in test stage; use 'all' for full set")
    parser.add_argument("--report_k", type=int, default=1, help="online HR reporting K in agent eval")
    parser.add_argument("--report_interval", type=int, default=50, help="online HR reporting interval")
    parser.add_argument("--max_epoch", type=int, default=4, help="max rec-user interaction rounds")
    parser.add_argument("--temperature", type=float, default=0.2, help="LLM temperature")
    parser.add_argument("--student_lora_path", type=str, default="./modelsaved/skill_student/qwen3_8b_in_lora")
    parser.add_argument("--test_only", action="store_true", default=False, help="load frozen artifacts and run test only")
    parser.add_argument(
        "--test_skill_ablation",
        type=str,
        default="none",
        choices=["none", "wo_user_profile", "wo_functional"],
        help="inference-only skill-pool ablation",
    )
    parser.add_argument(
        "--ablation_skill_top_k",
        type=int,
        default=0,
        help="single-pool ablation retrieval K; 0 keeps full model's configured total skill K",
    )
    parser.add_argument("--test_user_file", type=str, default="", help="optional ordered raw-user-id manifest")
    parser.add_argument("--ablation_dry_run", type=str2bool, default=False, help="emit detailed per-sample ablation diagnostics")
    parser.add_argument("--retriever_checkpoint", type=str, default="", help="explicit frozen skill retriever checkpoint")
    parser.add_argument(
        "--retriever_mode",
        type=str,
        default="trainable",
        choices=["trainable", "semantic"],
        help="Skill retriever mode; trainable preserves the full model behavior",
    )
    parser.add_argument(
        "--eval_output_dir",
        type=str,
        default="",
        help="optional experiment-specific directory for evaluation metrics",
    )
    parser.add_argument(
        "--prompt_log_path",
        type=str,
        default="",
        help="optional JSON/text prompt debug log; empty disables the global prompt log",
    )
    parser.add_argument(
        "--ablation_cache_path",
        type=str,
        default="",
        help="optional experiment-specific retrieval cache/output JSONL",
    )
    
    # ===== skill framework =====
    parser.add_argument("--enable_memskill", action="store_true", default=False, help="enable skill-centric recommendation")
    parser.add_argument("--skill_bank_path", type=str, default="./skills", help="path to the skill bank directory")
    parser.add_argument("--user_skill_top_k", type=int, default=2, help="retrieved user-profile skill count per action")
    parser.add_argument("--functional_skill_top_k", type=int, default=2, help="triggered functional skill count per action")
    parser.add_argument("--skill_update_interval", type=int, default=10, help="evolve the skill bank every N failed train cases")
    parser.add_argument("--failure_buffer_size", type=int, default=200, help="maximum number of failure cases stored in buffer")
    parser.add_argument("--max_skill_cases_per_round", type=int, default=20, help="maximum failure cases analyzed per evolution round")
    parser.add_argument("--initial_user_skill_budget", type=int, default=200, help="maximum train users used to bootstrap user skills")
    parser.add_argument("--user_skill_cluster_size", type=int, default=6, help="target prototype size when merging user skills")
    parser.add_argument("--skill_similarity_threshold", type=float, default=0.35, help="minimum similarity for user skill retrieval")
    parser.add_argument("--skill_debug_dir", type=str, default="", help="optional debug directory for prompts and skill snapshots")
    parser.add_argument("--debug_skill_prompts", type=str2bool, default=False, help="save prompts after skill injection")
    parser.add_argument("--skill_use_llm_summary", type=str2bool, default=False, help="use LLM to summarize histories when building skills")
    parser.add_argument("--skill_init_use_llm", type=str2bool, default=True, help="use LLM to build initial user-profile skills from train histories")
    parser.add_argument(
        "--skill_designer_variant",
        type=str,
        default="generic",
        choices=["generic", "lastfm", "instruments"],
        help="dataset-specific original prompt implementation used to initialize the Skill Bank",
    )
    parser.add_argument("--skill_evolve_use_llm", type=str2bool, default=True, help="use LLM to evolve skills from failed train interactions")
    parser.add_argument("--skill_update_rounds", type=int, default=1, help="how many second-pass update rounds to run on train users")
    parser.add_argument(
        "--disable_skill_evolution",
        action="store_true",
        default=False,
        help=(
            "collect failed recommendation trajectories normally, but never refine "
            "or evolve the initial Skill Bank from those failures"
        ),
    )
    parser.add_argument(
        "--user_skill_utilization_mode",
        type=str,
        default="original",
        choices=["original", "none", "retrieved", "mismatched"],
        help="controlled User-profile Skill intervention after normal AFL_v5 routing",
    )
    parser.add_argument(
        "--user_skill_mismatch_fraction",
        type=float,
        default=0.20,
        help="bottom-ranked same-dataset User-profile Skill pool fraction for mismatched mode",
    )
    return parser.parse_known_args()[0]
