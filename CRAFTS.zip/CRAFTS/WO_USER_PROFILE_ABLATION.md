# Qwen3-4B inference-time ablation: w/o User-profile Skills

This experiment is test-only. `main.py --test_only` bypasses benchmark splitting and
`ARLib.RecommendTrain()`, then loads the existing SASRec checkpoint, Qwen3-4B LoRA,
Skill Bank, trainable retriever projector, prior CSV, test split, and candidate JSON.

## Located full-model components

- Entry: `main.py -> ARLib.RecommendTest() -> ARS.test()`
- Backbone loader: `recommender/agent/ARS.worker_init() -> ARS/utils/local_request.py:QwenLocal`
- Skill Bank loader: `skill/skill_bank.py:SkillBank._load_if_exists()`
- Skill types: `user_profile` and `functional` in `skill_bank.json`
- Full retrieval: `skill/controller.py:SkillRouter.select_skills()`
- H@1: `recommender/agent/ARS.py:ARS.test()` and `_compute_overall_topk_metrics()`
- Test data: `data/clean/{dataset}/{dataset}.test.inter`
- Candidates: `modelsaved/ARS/{dataset}/candidates.json`

The original full Qwen3-4B logs use seed 2018, recommendation topK=1,
user-skill Top-2, functional-skill Top-2, max_epoch=1, temperature=0.2, and one worker.
This ablation retrieves four skills from the filtered Functional-only pool with the
existing trained projector. It does not retrieve a mixed pool and then delete skills.

## Commands

Dry run (five users per dataset):

```bash
python run_wo_user_profile_ablation.py --dataset all --dry-run --gpu-id 0
```

Full runs:

```bash
python run_wo_user_profile_ablation.py --dataset lastfm --gpu-id 0
python run_wo_user_profile_ablation.py --dataset movielens --gpu-id 0
python run_wo_user_profile_ablation.py --dataset instruments --gpu-id 0
```

Use `--print-commands` to print the fully expanded `main.py` commands without loading
models or changing outputs.

## Instruments 1,000-user manifest

No standalone 1,000-user Instruments test file existed in AFL_v5. The runner freezes
the first 1,000 users in the existing `Instruments.test.inter` order that also occur in
the original candidate JSON. It writes the manifest and source SHA-256 provenance under
the requested Instruments output directory; source test/candidate files are unchanged.
