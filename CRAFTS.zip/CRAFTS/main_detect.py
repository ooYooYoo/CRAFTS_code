import time
from conf.detect_parser import detect_parse_args
from util.DataLoader import DataLoader_detect
from util.tool import seedSet
from ARLib import ARLib_detect
import os
import torch
import numpy as np
import random


if __name__ == '__main__':

    # 1. Load configuration
    detect_args = detect_parse_args()
    # 2. Import recommend model and attack model
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    seed = 1
    seedSet(seed)

    import_str = 'from detect.' + detect_args.detectModelName + ' import ' + detect_args.detectModelName
    exec(import_str)

    # 3. Load data
    data = DataLoader_detect(detect_args)

    # 4. Define recommend model and attack model, and define ARLib to control the process
    detect_model = eval(detect_args.detectModelName)(detect_args, data)
    arlib = ARLib_detect(detect_model, detect_args)

    s = time.time()

    # 6. Attack
    # generate poison data, and then train/test in poisoning data (after attack)
    arlib.DetectFakeUser()

    # 7. N times experimental results analysis (on average)
    arlib.ResultAnalysis()

    e = time.time()
    print("Running time: %f s" % (e - s))
